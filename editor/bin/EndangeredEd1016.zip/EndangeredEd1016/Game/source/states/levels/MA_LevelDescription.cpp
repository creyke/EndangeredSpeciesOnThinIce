#include "MA_LevelDescription.h"
#include "MA_EntityDescription.h"
#include "all_gfx.h"
#include "..\..\MA_TileLibrary.h"

MA_LevelDescription::MA_LevelDescription()
{
	levelWidth = 0;
	levelHeight = 0;
	entityCount = 0;
	pickupCount = 0;
	signCount = 0;
	checkpointCount = 0;
	tileCount = 0;
	sharkNodeCount = 0;
	iceBlockCount = 0;
}

s32 MA_LevelDescription::GetLevelWidth()
{
	return this->levelWidth;
}
s32 MA_LevelDescription::GetLevelHeight()
{
	return this->levelHeight;
}
//MA_EntityDescription* MA_LevelDescription::GetEntities()
//{
//	return this->entities[0];
//}
MA_EntityDescription* MA_LevelDescription::GetEntity(int index)
{
	return this->entities[index];
}
u16 MA_LevelDescription::GetEntityCount()
{
	return this->entityCount;
}
u16 MA_LevelDescription::GetSignCount()
{
	return this->signCount;
}
u16 MA_LevelDescription::GetPickupCount()
{
	return this->pickupCount;
}
u16 MA_LevelDescription::GetCheckpointCount()
{
	return this->checkpointCount;
}
u16 MA_LevelDescription::GetTileCount()
{
	return this->tileCount;
}
u16 MA_LevelDescription::GetSharkCount()
{
	return this->sharkCount;
}
string MA_LevelDescription::GetLevelName()
{
	return this->levelName;
}
void MA_LevelDescription::CreateRandomMapTiles(u16 totalTiles)
{
	s32 spacing = 90<<8;
	s32 xPos = 0;
	s32 yPos  = 0;

	s32 randomOffset = 40<<8;
	s32 randomOffsetOverTwo = randomOffset/2;

	// Spacing between the edge of the ice blocks and the camera bound
	s32 mapOffset = 50<<8;

	// Used to determine size of map
	s32 maxBoundX = 0;
	s32 maxBoundY = 0;

	// Create a random map from two ice tiles
	// The map is created by first dividing the level space into tile 'slots'
	// Tiles are placed randomly in slots but are ensured to be joined to another tile
	// so that there arn't huge areas of water in between ice blocks
	u8 pCount = 1;
	u8 slotsX = 20;
	u8 slotsY = 20;
	bool slots[slotsX][slotsY];
	for (u8 x= 0; x < slotsX;x++)
		for (u8 y = 0; y < slotsY;y++)
			slots[x][y] = false;



	s8 assignedSlotsX[totalTiles];
	s8 assignedSlotsY[totalTiles];
	assignedSlotsX[0] = PA_RandMax(slotsX-1);
	assignedSlotsY[0] = PA_RandMax(slotsY-1);
	slots[assignedSlotsX[0]][assignedSlotsY[0]] = true;

	s8 directions[][2] = {{1, -1}, {1, 0}, {1, 1}, {0, -1},  {0, 1}, {-1, -1}, {-1, 0}, {-1, 1}};

	// Assigned all the map tiles into the slots
	while (pCount < totalTiles)
	{
		u8 slotIndex = PA_RandMax(pCount-1);

		u8 dir = PA_RandMax(7);
		s8 newX = assignedSlotsX[slotIndex] + directions[dir][0];
		s8 newY = assignedSlotsY[slotIndex] + directions[dir][1];
		if (newX >= 0 && newX < slotsX && newY >= 0 && newY < slotsY &&
			!slots[newX][newY])
		{
			slots[newX][newY] = true;
			assignedSlotsX[pCount] = newX;
			assignedSlotsY[pCount] = newY;
			pCount++;
		}
	}
	// Create entities for all the map tiles
	for (int i =0; i < totalTiles;i++)
	{
		s32 randX = (PA_RandMax( randomOffset) - randomOffsetOverTwo);
		s32 randY = (PA_RandMax(randomOffset) - randomOffsetOverTwo);

		xPos = ((s32)assignedSlotsX[i] * spacing + randX + mapOffset);
		yPos = ((s32)assignedSlotsY[i] * spacing + randY + mapOffset);
		// size the map to fit the tile
		if (xPos > maxBoundX)
			maxBoundX = xPos;
		if (yPos > maxBoundY)
			maxBoundY = yPos;

		// randomly make the tile move
		s32 moveVectorX = 0;
		s32 moveVectorY = 0;
		bool isMoving = PA_RandMax(2) == 0;
		if (isMoving)
		{
			moveVectorX = PA_RandMax(256) - 128;
			moveVectorY = PA_RandMax(256)- 128;

			if (moveVectorX != 0 || moveVectorY != 0)
			{
				s32 totalMovement = PA_RandMinMax(minRandomTileMove, maxRandomTileMove);
				float lengthVector = PA_TrueDistance(0, 0, moveVectorX, moveVectorY);
				moveVectorX = moveVectorX / lengthVector *totalMovement;
				moveVectorY = moveVectorY / lengthVector *totalMovement;
			}
		}
		// Create one of the two available tiles randomly
		this->AddTile(xPos, yPos, PA_RandMax(1), isMoving, moveVectorX, moveVectorY, PA_RandMinMax(6, 14));
	}

	// Set level dimensions
	this->levelWidth = maxBoundX + mapOffset;
	this->levelHeight = maxBoundY + mapOffset;
}

MA_LevelDescription* MA_LevelDescription::CreateRandomMap(u16 tileCount)
{
	MA_LevelDescription* randomLevel = new MA_LevelDescription();
	//randomLevel->entities = new MA_EntityDescription*[tileCount * 2];

	randomLevel->CreateRandomMapTiles(tileCount);
	randomLevel->CreateRandomCheckpoints();
	randomLevel->CreateRandomCollectables();

	// Assume the penguin will be created in the middle of the map
	s32 penguinPosX = randomLevel->levelWidth / 2;
	s32 penguinPosY = randomLevel->levelHeight / 2;

	//Set the pengin start position to a random island
	if (randomLevel->tileCount > 0)
	{
		u8 randomMapTile = PA_RandMax(randomLevel->tileCount-1);
		penguinPosX = randomLevel->tiles[randomMapTile]->x + mapTileSizeOverTwo;
		penguinPosY = randomLevel->tiles[randomMapTile]->y + mapTileSizeOverTwo;
	}
	// Add the player to the random map
	randomLevel->AddPenguin(penguinPosX, penguinPosY);

	// End of random map
	return randomLevel;
}
void MA_LevelDescription::CreateRandomCheckpoints()
{
	bool assignedMapTiles[this->tileCount];
	for (u8 i = 0; i < this->tileCount;i++)
		assignedMapTiles[i] = false;


	u16 totalCheckpoints = this->tileCount / 10;

	u8 mapTileIndex = 0;
	while (this->checkpointCount < totalCheckpoints)
	{
		mapTileIndex = PA_RandMax(this->tileCount-1);

		if (!assignedMapTiles[mapTileIndex])
		{
			assignedMapTiles[mapTileIndex]= true;

			this->AddCheckpoint(
				this->tiles[mapTileIndex]->x  + mapTileSizeOverTwo, 
				this->tiles[mapTileIndex]->y  + mapTileSizeOverTwo, 0, 0, (void*)snowman_Sprite, OBJ_SIZE_64X64);
		}
	}
}
void MA_LevelDescription::CreateRandomCollectables()
{

	u8 mapTileIndex = 0;
	bool assignedMapTiles[this->tileCount];
	for (u8 i = 0; i < this->tileCount;i++)
		assignedMapTiles[i] = false;

	u16 maxCollectables  = this->tileCount / 2;

	while (this->pickupCount < maxCollectables)
	{
		mapTileIndex = PA_RandMax(this->tileCount-1);
		if (!assignedMapTiles[mapTileIndex])
		{
			assignedMapTiles[mapTileIndex]= true;

			this->AddCollectable(
				this->tiles[mapTileIndex]->x  + mapTileSizeOverTwo, 
				this->tiles[mapTileIndex]->y  + mapTileSizeOverTwo, 0, 0, (void*)fishjump_Sprite, OBJ_SIZE_32X32 );
		}
	}
}

void MA_LevelDescription::AddEnvironmentEntity(s32 x, s32 y, u8 environmentID)
{
	MA_EntityDescription* entity = new MA_EntityDescription(EType_Environment, x, y, 0, 0, 0,0, 0, 0);
	switch (environmentID)
	{
	case 0:
		{
			entity->spriteData = (void*)E0_StartGate_Sprite;
			entity->shape = 0;
			entity->size = 3;
			entity->paletteID = 15;
			entity->offsetX = 32<<8;
			entity->offsetY = 64<<8;
			entity->autoSortDepth = true;
		}
		break;
	case 1:
		{
			entity->spriteData = (void*)E1_FinishGate_Sprite;
			entity->shape = 0;
			entity->size = 3;
			entity->paletteID = 16;
			entity->offsetX = 32<<8;
			entity->offsetY = 32<<8;
			entity->autoSortDepth = true;
		}
		break;
	case 2:
		{
			entity->spriteData = (void*)E2_BoatWreck_Sprite;
			entity->shape = 0;
			entity->size = 3;
			entity->paletteID = 14;
			entity->offsetX = 32<<8;
			entity->offsetY = 32<<8;
		}
		break;
	case 3:
		{
			entity->spriteData = (void*)E3_Skeleton_Sprite;
			entity->shape = 0;
			entity->size = 3;
			entity->paletteID = 14;
			entity->offsetX = 32<<8;
			entity->offsetY = 32<<8;
		}
		break;

	default:
		break;
	}
	
	this->entities[this->entityCount++] = entity;
}


void MA_LevelDescription::AddSign(s32 x, s32 y, string signText, u8 signFrame)
{
	MA_EntityDescription* sign = new MA_EntityDescription(EType_Sign, x, y, 0, 0, 0,0, 0, 0);
	sign->signText = signText;
	sign->signFrame = signFrame;
	this->entities[this->entityCount++] = sign;
	this->pickupCount++;
}
// Old function kept in for compatability
void MA_LevelDescription::AddSign(s32 x, s32 y, s32 offsetX, s32 offsetY, void* spriteData, u8 shape, u8 size, string txt)
{
	this->AddSign(x,y, txt, 0);
}
void MA_LevelDescription::AddCollectable(s32 x, s32 y, s32 offsetX, s32 offsetY, void* spriteData, u8 shape, u8 size)
{
	MA_EntityDescription* pickup = new MA_EntityDescription(EType_Pickup, x, y, 0, 0, spriteData,shape, size, 0);
	this->entities[this->entityCount++] = pickup;
	this->pickupCount++;
}
void MA_LevelDescription::AddCheckpoint(s32 x, s32 y, s32 offsetX, s32 offsetY, void* spriteData, u8 shape, u8 size)
{
	MA_EntityDescription* checkpoint = new MA_EntityDescription(EType_Checkpoint, x, y, 0, 0, spriteData, shape, size, 0);
	this->entities[this->entityCount++] = checkpoint;
	this->checkpointCount++;
}
void MA_LevelDescription::AddTile(s32 x, s32 y, u8 tileIndex, bool isMoving, s32 moveVectorX, s32 moveVectorY, s32 moveSpeed)
{
	MA_EntityDescription* tile = new MA_EntityDescription(EType_Tile, x, y, 0, 0, 0, OBJ_SIZE_64X64, 0);
	tile->isMoving = isMoving;
	tile->moveVectorX = moveVectorX;
	tile->moveVectorY = moveVectorY;
	tile->moveSpeed = moveSpeed;
	tile->tileIndex = tileIndex;
	this->tiles[this->tileCount++] = tile;
	this->entities[this->entityCount++] = tile;
}
void MA_LevelDescription::AddPenguin(s32 x, s32 y)
{
	// Only x and y position used for penguin
	MA_EntityDescription* penguin = new MA_EntityDescription(EType_Penguin, x, y, 0, 0, 0, 0, 0, 0);
	this->entities[this->entityCount++] = penguin;
}
void MA_LevelDescription::AddPolarBear(s32 x, s32 y)
{
	MA_EntityDescription* polarBear = new MA_EntityDescription(EType_PolarBear, x, y, 0, 0, 0, 0, 0, 0);
	this->entities[this->entityCount++] = polarBear;
}
void MA_LevelDescription::AddShark(u16 sharkNodeIndex)
{
	MA_EntityDescription* shark = new MA_EntityDescription(EType_Shark, 0, 0, 0, 0, 0, 0, 0, 0);
	shark->sharkStartNode = sharkNodeIndex;
	this->entities[this->entityCount++] = shark;
}
void MA_LevelDescription::AddStartGate(s32 x, s32 y)
{
	AddEnvironmentEntity(x, y, 0);
	entities[this->entityCount-1]->eType = EType_StartGate;
}
void MA_LevelDescription::AddFinishGate(s32 x, s32 y)
{
	AddEnvironmentEntity(x, y, 1);
	entities[this->entityCount-1]->eType = EType_FinishGate;
}
void MA_LevelDescription::AddIceBlock(s32 x, s32 y)
{
	MA_EntityDescription* iceBlock = new MA_EntityDescription(EType_IceBlock, x, y, 0, 0, 0, OBJ_SIZE_32X32, 0);
	this->entities[this->entityCount++] = iceBlock;
	this->iceBlockCount++;
}
int MA_LevelDescription::GetSharkNodeCount()
{
	return this->sharkNodeCount;
}
MA_Node* MA_LevelDescription::GetSharkNodes()
{
	return this->sharkNodes;
}
u16 MA_LevelDescription::GetTimeRequirement(int awardIndex)
{
	return this->totalTimeRequirements[awardIndex];
}
u16 MA_LevelDescription::GetPickupRequirement(int awardIndex)
{
	return this->pickupRequirements[awardIndex];
}
	// Helper function that creates a group of tiles with the top left corner being at the x and y index
void  MA_LevelDescription::CreateTileSet(s32 x, s32 y, u8 tileGroupIndex, bool isMoving, s32 moveVectorX, s32 moveVectorY, s32 moveSpeed)
{
	MA_EntityDescription* tileGroupEntity = new MA_EntityDescription(EType_TileGroup, x, y, 0, 0, 0, 0, 0, 0);
	tileGroupEntity->tileGroupIndex = tileGroupIndex;
	this->entities[this->entityCount++] = tileGroupEntity;

	int count = 0;
	for (int ty = 0; ty < MA_TileLibrary::TileGroupDimensions[tileGroupIndex][1];ty++)
	{
		for (int tx = 0; tx < MA_TileLibrary::TileGroupDimensions[tileGroupIndex][0];tx++)
		{
			AddTile(x + ((64 * tx)<<8), y + ((64 * ty)<<8), MA_TileLibrary::TileGroupTiles[tileGroupIndex][count++], isMoving, moveVectorX, moveVectorY, moveSpeed); 
		}
	}
	//switch (tileGroupIndex)
	//{
	//	case 0:
	//		{
	//			AddTile(x, y, 0, isMoving, moveVectorX, moveVectorY, moveSpeed); 
	//		}
	//		break;
	//	case 1:
	//		{
	//			AddTile(x, y, 1, isMoving, moveVectorX, moveVectorY, moveSpeed); 
	//		}
	//		break;
	//	case 2:
	//		{
	//			AddTile(x, y, 2, isMoving, moveVectorX, moveVectorY, moveSpeed); 
	//		}
	//		break;
	//	case 3:
	//		{
	//			this->AddTile(	x,		y, 3, isMoving, moveVectorX, moveVectorY, moveSpeed);
	//			this->AddTile(	x + (64<<8),	y, 4, isMoving, moveVectorX, moveVectorY, moveSpeed);
	//			this->AddTile(	x + (128<<8),	y, 5, isMoving, moveVectorX, moveVectorY, moveSpeed);
	//			this->AddTile(	x + (192<<8),	y, 6, isMoving, moveVectorX, moveVectorY, moveSpeed);
	//			y += 64<<8;
	//			this->AddTile(	x,				y, 7, isMoving, moveVectorX, moveVectorY, moveSpeed);
	//			this->AddTile(	x + (64<<8),	y, 15, isMoving, moveVectorX, moveVectorY, moveSpeed);
	//			this->AddTile(	x + (128<<8),	y, 15,  isMoving, moveVectorX, moveVectorY, moveSpeed);
	//			this->AddTile(	x + (192<<8),	y, 8,  isMoving, moveVectorX, moveVectorY, moveSpeed);
	//			y += 64<<8;
	//			this->AddTile(	x,				y, 9, isMoving, moveVectorX, moveVectorY, moveSpeed);
	//			this->AddTile(	x + (64<<8),	y, 15,  isMoving, moveVectorX, moveVectorY, moveSpeed);
	//			this->AddTile(	x + (128<<8),	y, 15,  isMoving, moveVectorX, moveVectorY, moveSpeed);
	//			this->AddTile(	x + (192<<8),	y, 10,  isMoving, moveVectorX, moveVectorY, moveSpeed);
	//			y += 64<<8;
	//			this->AddTile(	x,				y, 11,  isMoving, moveVectorX, moveVectorY, moveSpeed);
	//			this->AddTile(	x + (64<<8),	y, 12,  isMoving, moveVectorX, moveVectorY, moveSpeed);
	//			this->AddTile(	x + (128<<8),	y, 13,  isMoving, moveVectorX, moveVectorY, moveSpeed);
	//			this->AddTile(	x + (192<<8),	y, 14,  isMoving, moveVectorX, moveVectorY, moveSpeed);
	//		}
	//		break;
	//	case 4:
	//		{
	//			AddTile(x, y, 15, isMoving, moveVectorX, moveVectorY, moveSpeed); 
	//		}
	//		break;
	//	case 5:
	//		{
	//			this->AddTile(	x,				y, 16,  isMoving, moveVectorX, moveVectorY, moveSpeed);
	//			this->AddTile(	x + (64<<8),	y, 17,  isMoving, moveVectorX, moveVectorY, moveSpeed);
	//			y += 64<<8;
	//			this->AddTile(	x,				y, 18,  isMoving, moveVectorX, moveVectorY, moveSpeed);
	//			this->AddTile(	x + (64<<8),	y, 19,  isMoving, moveVectorX, moveVectorY, moveSpeed);
	//		}
	//		break;
	//	case 6:
	//		{

	//			this->AddTile(	x,				y,	20,  isMoving, moveVectorX, moveVectorY, moveSpeed);
	//			this->AddTile(	x + (64<<8),	y,	21,  isMoving, moveVectorX, moveVectorY, moveSpeed);
	//			this->AddTile(	x + (128<<8),	y,	22,  isMoving, moveVectorX, moveVectorY, moveSpeed);
	//			y += 64<<8;
	//			this->AddTile(	x,				y,	23,  isMoving, moveVectorX, moveVectorY, moveSpeed);
	//			this->AddTile(	x + (64<<8),	y,	15,  isMoving, moveVectorX, moveVectorY, moveSpeed);
	//			this->AddTile(	x + (128<<8),	y,	24,  isMoving, moveVectorX, moveVectorY, moveSpeed);
	//			y += 64<<8;
	//			this->AddTile(	x,				y,	25,  isMoving, moveVectorX, moveVectorY, moveSpeed);
	//			this->AddTile(	x + (64<<8),	y,	26,  isMoving, moveVectorX, moveVectorY, moveSpeed);
	//			this->AddTile(	x + (128<<8),	y,	27,  isMoving, moveVectorX, moveVectorY, moveSpeed);

	//		}
	//		break;
	//	case 7:
	//		{
	//			this->AddTile(	x,				y,	28, isMoving, moveVectorX, moveVectorY, moveSpeed);
	//			this->AddTile(	x + (64<<8),	y,	29, isMoving, moveVectorX, moveVectorY, moveSpeed);
	//			this->AddTile(	x + (128<<8),	y,	30, isMoving, moveVectorX, moveVectorY, moveSpeed);
	//			this->AddTile(	x + (192<<8),	y,	31, isMoving, moveVectorX, moveVectorY, moveSpeed);
	//			y += 64<<8;
	//			this->AddTile(	x,				y,	32, isMoving, moveVectorX, moveVectorY, moveSpeed);
	//			this->AddTile(	x + (64<<8),	y,	15, isMoving, moveVectorX, moveVectorY, moveSpeed);
	//			this->AddTile(	x + (128<<8),	y,	15,  isMoving, moveVectorX, moveVectorY, moveSpeed);
	//			this->AddTile(	x + (192<<8),	y,	33,  isMoving, moveVectorX, moveVectorY, moveSpeed);
	//			y += 64<<8;
	//			this->AddTile(	x,				y,	34, isMoving, moveVectorX, moveVectorY, moveSpeed);
	//			this->AddTile(	x + (64<<8),	y,	15,  isMoving, moveVectorX, moveVectorY, moveSpeed);
	//			this->AddTile(	x + (128<<8),	y,	15,  isMoving, moveVectorX, moveVectorY, moveSpeed);
	//			this->AddTile(	x + (192<<8),	y,	35,  isMoving, moveVectorX, moveVectorY, moveSpeed);
	//			y += 64<<8;
	//			this->AddTile(	x,				y,	36,  isMoving, moveVectorX, moveVectorY, moveSpeed);
	//			this->AddTile(	x + (64<<8),	y,	37,  isMoving, moveVectorX, moveVectorY, moveSpeed);
	//			this->AddTile(	x + (128<<8),	y,	38,  isMoving, moveVectorX, moveVectorY, moveSpeed);
	//			this->AddTile(	x + (192<<8),	y,	39,  isMoving, moveVectorX, moveVectorY, moveSpeed);
	//		}
	//		break;
	//	case 8:
	//		{
	//			this->AddTile(	x,				y,	40, isMoving, moveVectorX, moveVectorY, moveSpeed);
	//			this->AddTile(	x + (64<<8),	y,	41, isMoving, moveVectorX, moveVectorY, moveSpeed);
	//			this->AddTile(	x + (128<<8),	y,	42, isMoving, moveVectorX, moveVectorY, moveSpeed);
	//			this->AddTile(	x + (192<<8),	y,	43, isMoving, moveVectorX, moveVectorY, moveSpeed);
	//			this->AddTile(	x + (256<<8),	y,	44, isMoving, moveVectorX, moveVectorY, moveSpeed);
	//			y += 64<<8;
	//			this->AddTile(	x,				y,	45, isMoving, moveVectorX, moveVectorY, moveSpeed);
	//			this->AddTile(	x + (64<<8),	y,	15, isMoving, moveVectorX, moveVectorY, moveSpeed);
	//			this->AddTile(	x + (128<<8),	y,	15,  isMoving, moveVectorX, moveVectorY, moveSpeed);
	//			this->AddTile(	x + (192<<8),	y,	15,  isMoving, moveVectorX, moveVectorY, moveSpeed);
	//			this->AddTile(	x + (256<<8),	y,	46,  isMoving, moveVectorX, moveVectorY, moveSpeed);
	//			y += 64<<8;
	//			this->AddTile(	x,				y,	47, isMoving, moveVectorX, moveVectorY, moveSpeed);
	//			this->AddTile(	x + (64<<8),	y,	15,  isMoving, moveVectorX, moveVectorY, moveSpeed);
	//			this->AddTile(	x + (128<<8),	y,	15,  isMoving, moveVectorX, moveVectorY, moveSpeed);
	//			this->AddTile(	x + (192<<8),	y,	15,  isMoving, moveVectorX, moveVectorY, moveSpeed);
	//			this->AddTile(	x + (256<<8),	y,	48,  isMoving, moveVectorX, moveVectorY, moveSpeed);
	//							y += 64<<8;
	//			this->AddTile(	x,				y,	49, isMoving, moveVectorX, moveVectorY, moveSpeed);
	//			this->AddTile(	x + (64<<8),	y,	15,  isMoving, moveVectorX, moveVectorY, moveSpeed);
	//			this->AddTile(	x + (128<<8),	y,	15,  isMoving, moveVectorX, moveVectorY, moveSpeed);
	//			this->AddTile(	x + (192<<8),	y,	15,  isMoving, moveVectorX, moveVectorY, moveSpeed);
	//			this->AddTile(	x + (256<<8),	y,	50,  isMoving, moveVectorX, moveVectorY, moveSpeed);
	//			y += 64<<8;
	//			this->AddTile(	x,				y,	51,  isMoving, moveVectorX, moveVectorY, moveSpeed);
	//			this->AddTile(	x + (64<<8),	y,	52,  isMoving, moveVectorX, moveVectorY, moveSpeed);
	//			this->AddTile(	x + (128<<8),	y,	53,  isMoving, moveVectorX, moveVectorY, moveSpeed);
	//			this->AddTile(	x + (192<<8),	y,	54,  isMoving, moveVectorX, moveVectorY, moveSpeed);
	//			this->AddTile(	x + (256<<8),	y,	55,  isMoving, moveVectorX, moveVectorY, moveSpeed);
	//		}
	//		break;
	//	case 9:
	//		{
	//			this->AddTile( x,				y, 56, isMoving, moveVectorX, moveVectorY, moveSpeed); 
	//		}
	//		break;
	//	case 10:
	//		{
	//			this->AddTile(	x,				y, 57,  isMoving, moveVectorX, moveVectorY, moveSpeed);
	//			this->AddTile(	x + (64<<8),	y, 58,  isMoving, moveVectorX, moveVectorY, moveSpeed);
	//			y += 64<<8;
	//			this->AddTile(	x,				y, 59,  isMoving, moveVectorX, moveVectorY, moveSpeed);
	//			this->AddTile(	x + (64<<8),	y, 60,  isMoving, moveVectorX, moveVectorY, moveSpeed);
	//		}
	//		break;
	//	case 11:
	//		{
	//			this->AddTile(	x,				y, 61,  isMoving, moveVectorX, moveVectorY, moveSpeed);
	//			this->AddTile(	x + (64<<8),	y, 62,  isMoving, moveVectorX, moveVectorY, moveSpeed);
	//			y += 64<<8;
	//			this->AddTile(	x,				y, 63,  isMoving, moveVectorX, moveVectorY, moveSpeed);
	//			this->AddTile(	x + (64<<8),	y, 64,  isMoving, moveVectorX, moveVectorY, moveSpeed);
	//		}
	//		break;
	//	case 12:
	//		{
	//			this->AddTile(	x,				y, 65,  isMoving, moveVectorX, moveVectorY, moveSpeed);
	//			this->AddTile(	x + (64<<8),	y, 66,  isMoving, moveVectorX, moveVectorY, moveSpeed);
	//			y += 64<<8;
	//			this->AddTile(	x,				y, 67,  isMoving, moveVectorX, moveVectorY, moveSpeed);
	//			this->AddTile(	x + (64<<8),	y, 68,  isMoving, moveVectorX, moveVectorY, moveSpeed);
	//		}
	//		break;
	//	case 13:
	//		{
	//			this->AddTile(	x,				y, 69,  isMoving, moveVectorX, moveVectorY, moveSpeed);
	//			this->AddTile(	x + (64<<8),	y, 70,  isMoving, moveVectorX, moveVectorY, moveSpeed);
	//			y += 64<<8;
	//			this->AddTile(	x,				y, 71,  isMoving, moveVectorX, moveVectorY, moveSpeed);
	//			this->AddTile(	x + (64<<8),	y, 72,  isMoving, moveVectorX, moveVectorY, moveSpeed);
	//		}
	//		break;
	//	default:
	//		break;
	//}
}