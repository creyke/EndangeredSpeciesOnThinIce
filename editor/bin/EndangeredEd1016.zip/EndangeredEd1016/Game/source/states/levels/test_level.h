// All code Copyright © 2010 Mobile Asylum
//   Level generated with EndangeredEd v1.0.1.2
//
// Level Name:          Testing Level
// Level Author(s):     gsd
// Build Date/Time:     12/04/2010 14:11:25
// Map File Location:   "C:\Working\Projects\game\Editor\EndangeredEd\bin\x86\Debug\Levels"
// Map File Name:       "test_level.esl"
//

#pragma once

#include "MA_LevelDescription.h"

class test_level : public MA_LevelDescription
{
public:
    test_level();
};

