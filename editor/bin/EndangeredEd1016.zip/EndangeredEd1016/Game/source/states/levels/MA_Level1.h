// All code Copyright © 2010 Mobile Asylum
//   Level generated with EndangeredEd v1.0.1.0
//
// Level Name:          Tenderfoot Pass
// Level Author(s):     Roger Creyke
// Build Date/Time:     16/03/2010 03:14:26
// Map File Location:   "C:\Working\Projects\game\Editor\EndangeredEd\bin\x86\Debug\Levels"
// Map File Name:       "Level1-TenderfootPass.esl"
//

#pragma once

#include "MA_LevelDescription.h"

class MA_Level1 : public MA_LevelDescription
{
public:
    MA_Level1();
};

