// All code Copyright © 2010 Mobile Asylum
//   Level generated with EndangeredEd v1.0.1.0
//
// Level Name:          Cold Feet Retreat
// Level Author(s):     Dean Leeks
// Build Date/Time:     16/03/2010 03:17:16
// Map File Location:   "C:\Working\Projects\game\Editor\EndangeredEd\bin\x86\Debug\Levels"
// Map File Name:       "Level3-ColdFeetRetreat.esl"
//

#include "MA_LevelContainer.h"
#include "MA_Level3.h"
#include "all_gfx.h"

MA_Level3::MA_Level3() : MA_LevelDescription()
{
    // NB all coordinates are (x<<8)
    this->levelName = "Cold Feet Retreat";
    
    // Set the dimension of the level
    this->levelWidth = 1024<<8;
    this->levelHeight = 1024<<8;
    
    // Define the goal requirements for pickups (gold, silver, bronze)
    this->pickupRequirements[0] = 40;
    this->pickupRequirements[1] = 30;
    this->pickupRequirements[2] = 20;
    
    // Define the time allowance in seconds for gold, silver, bronze
    this->totalTimeRequirements[0] = 0;
    this->totalTimeRequirements[1] = 0;
    this->totalTimeRequirements[2] = 0;
    
    // Add some tiles (xPos, yPos, tileIndex, moving, moveVectorX, movevectorY, movespeed)
    this->CreateTileSet(204<<8, 170<<8, 0, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(139<<8, 107<<8, 0, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(282<<8, 81<<8, 0, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(159<<8, 234<<8, 0, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(99<<8, 37<<8, 0, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(249<<8, 17<<8, 0, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(27<<8, 322<<8, 0, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(329<<8, 13<<8, 0, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(324<<8, 146<<8, 0, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(63<<8, 394<<8, 0, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(173<<8, 27<<8, 0, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(95<<8, 279<<8, 0, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(359<<8, 211<<8, 0, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(223<<8, 443<<8, 0, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(134<<8, 431<<8, 0, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(27<<8, 19<<8, 0, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(282<<8, 311<<8, 0, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(191<<8, 513<<8, 0, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(113<<8, 563<<8, 0, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(56<<8, 630<<8, 0, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(46<<8, 712<<8, 0, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(121<<8, 738<<8, 0, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(198<<8, 731<<8, 0, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(407<<8, 26<<8, 0, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(485<<8, 41<<8, 0, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(557<<8, 72<<8, 0, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(552<<8, 137<<8, 0, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(601<<8, 191<<8, 0, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(636<<8, 57<<8, 0, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(713<<8, 40<<8, 0, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(790<<8, 22<<8, 0, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(870<<8, 14<<8, 0, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(945<<8, 40<<8, 0, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(573<<8, 254<<8, 0, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(501<<8, 281<<8, 0, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(497<<8, 352<<8, 0, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(227<<8, 263<<8, 0, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(266<<8, 704<<8, 0, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(293<<8, 446<<8, 0, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(368<<8, 468<<8, 0, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(420<<8, 528<<8, 0, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(451<<8, 595<<8, 0, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(443<<8, 667<<8, 0, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(507<<8, 723<<8, 0, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(480<<8, 807<<8, 0, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(394<<8, 849<<8, 0, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(370<<8, 924<<8, 0, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(294<<8, 897<<8, 0, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(231<<8, 952<<8, 0, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(90<<8, 955<<8, 0, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(50<<8, 896<<8, 0, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(19<<8, 956<<8, 0, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(537<<8, 562<<8, 0, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(165<<8, 905<<8, 0, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(917<<8, 105<<8, 0, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(852<<8, 149<<8, 0, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(772<<8, 149<<8, 0, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(729<<8, 203<<8, 0, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(755<<8, 266<<8, 0, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(820<<8, 315<<8, 0, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(898<<8, 313<<8, 0, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(930<<8, 383<<8, 0, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(883<<8, 452<<8, 0, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(803<<8, 445<<8, 0, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(730<<8, 407<<8, 0, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(668<<8, 463<<8, 0, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(622<<8, 531<<8, 0, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(692<<8, 569<<8, 0, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(775<<8, 567<<8, 0, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(850<<8, 598<<8, 0, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(923<<8, 646<<8, 0, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(936<<8, 718<<8, 0, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(953<<8, 790<<8, 0, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(938<<8, 872<<8, 0, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(886<<8, 938<<8, 0, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(808<<8, 954<<8, 0, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(720<<8, 951<<8, 0, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(653<<8, 919<<8, 0, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(642<<8, 854<<8, 0, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(656<<8, 783<<8, 0, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(729<<8, 765<<8, 0, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(681<<8, 712<<8, 0, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(712<<8, 830<<8, 0, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(790<<8, 808<<8, 0, false, 0<<8, 0<<8, 1);
    
    // Add pickups
    this->AddCollectable(130<<8, 66<<8, 16<<8, 20<<8, (void*)fishjump_Sprite, OBJ_SIZE_32X32);
    this->AddCollectable(391<<8, 229<<8, 16<<8, 20<<8, (void*)fishjump_Sprite, OBJ_SIZE_32X32);
    this->AddCollectable(374<<8, 246<<8, 16<<8, 20<<8, (void*)fishjump_Sprite, OBJ_SIZE_32X32);
    this->AddCollectable(403<<8, 250<<8, 16<<8, 20<<8, (void*)fishjump_Sprite, OBJ_SIZE_32X32);
    this->AddCollectable(126<<8, 299<<8, 16<<8, 20<<8, (void*)fishjump_Sprite, OBJ_SIZE_32X32);
    this->AddCollectable(301<<8, 343<<8, 16<<8, 20<<8, (void*)fishjump_Sprite, OBJ_SIZE_32X32);
    this->AddCollectable(162<<8, 458<<8, 16<<8, 20<<8, (void*)fishjump_Sprite, OBJ_SIZE_32X32);
    this->AddCollectable(147<<8, 594<<8, 16<<8, 20<<8, (void*)fishjump_Sprite, OBJ_SIZE_32X32);
    this->AddCollectable(286<<8, 727<<8, 16<<8, 20<<8, (void*)fishjump_Sprite, OBJ_SIZE_32X32);
    this->AddCollectable(289<<8, 748<<8, 16<<8, 20<<8, (void*)fishjump_Sprite, OBJ_SIZE_32X32);
    this->AddCollectable(312<<8, 737<<8, 16<<8, 20<<8, (void*)fishjump_Sprite, OBJ_SIZE_32X32);
    this->AddCollectable(93<<8, 916<<8, 16<<8, 20<<8, (void*)fishjump_Sprite, OBJ_SIZE_32X32);
    this->AddCollectable(68<<8, 935<<8, 16<<8, 20<<8, (void*)fishjump_Sprite, OBJ_SIZE_32X32);
    this->AddCollectable(129<<8, 972<<8, 16<<8, 20<<8, (void*)fishjump_Sprite, OBJ_SIZE_32X32);
    this->AddCollectable(119<<8, 1000<<8, 16<<8, 20<<8, (void*)fishjump_Sprite, OBJ_SIZE_32X32);
    this->AddCollectable(44<<8, 978<<8, 16<<8, 20<<8, (void*)fishjump_Sprite, OBJ_SIZE_32X32);
    this->AddCollectable(65<<8, 993<<8, 16<<8, 20<<8, (void*)fishjump_Sprite, OBJ_SIZE_32X32);
    this->AddCollectable(40<<8, 1001<<8, 16<<8, 20<<8, (void*)fishjump_Sprite, OBJ_SIZE_32X32);
    this->AddCollectable(519<<8, 371<<8, 16<<8, 20<<8, (void*)fishjump_Sprite, OBJ_SIZE_32X32);
    this->AddCollectable(542<<8, 383<<8, 16<<8, 20<<8, (void*)fishjump_Sprite, OBJ_SIZE_32X32);
    this->AddCollectable(516<<8, 393<<8, 16<<8, 20<<8, (void*)fishjump_Sprite, OBJ_SIZE_32X32);
    this->AddCollectable(741<<8, 74<<8, 16<<8, 20<<8, (void*)fishjump_Sprite, OBJ_SIZE_32X32);
    this->AddCollectable(907<<8, 49<<8, 16<<8, 20<<8, (void*)fishjump_Sprite, OBJ_SIZE_32X32);
    this->AddCollectable(885<<8, 184<<8, 16<<8, 20<<8, (void*)fishjump_Sprite, OBJ_SIZE_32X32);
    this->AddCollectable(759<<8, 238<<8, 16<<8, 20<<8, (void*)fishjump_Sprite, OBJ_SIZE_32X32);
    this->AddCollectable(855<<8, 345<<8, 16<<8, 20<<8, (void*)fishjump_Sprite, OBJ_SIZE_32X32);
    this->AddCollectable(961<<8, 419<<8, 16<<8, 20<<8, (void*)fishjump_Sprite, OBJ_SIZE_32X32);
    this->AddCollectable(839<<8, 473<<8, 16<<8, 20<<8, (void*)fishjump_Sprite, OBJ_SIZE_32X32);
    this->AddCollectable(703<<8, 728<<8, 16<<8, 20<<8, (void*)fishjump_Sprite, OBJ_SIZE_32X32);
    this->AddCollectable(733<<8, 742<<8, 16<<8, 20<<8, (void*)fishjump_Sprite, OBJ_SIZE_32X32);
    this->AddCollectable(705<<8, 757<<8, 16<<8, 20<<8, (void*)fishjump_Sprite, OBJ_SIZE_32X32);
    this->AddCollectable(752<<8, 782<<8, 16<<8, 20<<8, (void*)fishjump_Sprite, OBJ_SIZE_32X32);
    this->AddCollectable(768<<8, 805<<8, 16<<8, 20<<8, (void*)fishjump_Sprite, OBJ_SIZE_32X32);
    this->AddCollectable(838<<8, 843<<8, 16<<8, 20<<8, (void*)fishjump_Sprite, OBJ_SIZE_32X32);
    this->AddCollectable(810<<8, 852<<8, 16<<8, 20<<8, (void*)fishjump_Sprite, OBJ_SIZE_32X32);
    this->AddCollectable(678<<8, 804<<8, 16<<8, 20<<8, (void*)fishjump_Sprite, OBJ_SIZE_32X32);
    this->AddCollectable(706<<8, 812<<8, 16<<8, 20<<8, (void*)fishjump_Sprite, OBJ_SIZE_32X32);
    this->AddCollectable(755<<8, 848<<8, 16<<8, 20<<8, (void*)fishjump_Sprite, OBJ_SIZE_32X32);
    this->AddCollectable(730<<8, 867<<8, 16<<8, 20<<8, (void*)fishjump_Sprite, OBJ_SIZE_32X32);
    this->AddCollectable(668<<8, 870<<8, 16<<8, 20<<8, (void*)fishjump_Sprite, OBJ_SIZE_32X32);
    this->AddCollectable(682<<8, 900<<8, 16<<8, 20<<8, (void*)fishjump_Sprite, OBJ_SIZE_32X32);
    
    // Add signs
    this->AddSign(295<<8, 42<<8, 30<<8, 50<<8, (void*)sign_3_Sprite, OBJ_SIZE_64X64, "");
    this->AddSign(565<<8, 155<<8, 34<<8, 52<<8, (void*)sign_3_Sprite, OBJ_SIZE_64X64, "");
    this->AddSign(268<<8, 274<<8, 30<<8, 50<<8, (void*)sign_3_Sprite, OBJ_SIZE_64X64, "");
    this->AddSign(261<<8, 455<<8, 35<<8, 52<<8, (void*)sign_3_Sprite, OBJ_SIZE_64X64, "");
    
    // Add checkpoints
    this->AddCheckpoint(40<<8, 351<<8, 30<<8, 50<<8, (void*)snowman_Sprite, OBJ_SIZE_64X64);
    this->AddCheckpoint(369<<8, 164<<8, 30<<8, 50<<8, (void*)snowman_Sprite, OBJ_SIZE_64X64);
    this->AddCheckpoint(66<<8, 746<<8, 30<<8, 50<<8, (void*)snowman_Sprite, OBJ_SIZE_64X64);
    this->AddCheckpoint(412<<8, 490<<8, 30<<8, 50<<8, (void*)snowman_Sprite, OBJ_SIZE_64X64);
    this->AddCheckpoint(778<<8, 288<<8, 30<<8, 50<<8, (void*)snowman_Sprite, OBJ_SIZE_64X64);
    this->AddCheckpoint(980<<8, 745<<8, 30<<8, 50<<8, (void*)snowman_Sprite, OBJ_SIZE_64X64);
    
    // Add penguin
    this->AddPenguin(52<<8, 54<<8);
    
    // Create shark nodes - make sure to give the nodes neighbours otherwise the shark will get stuck
    this->sharkNodeCount = 8;
    
    // Create an array of nodes
    this->sharkNodes = new MA_Node[this->sharkNodeCount];
    
    this->sharkNodes[0].X = 578 << 8;
    this->sharkNodes[0].Y = 426 << 8;
    this->sharkNodes[0].AddNeighbour(1);
    this->AddShark(0);
    
    this->sharkNodes[1].X = 693 << 8;
    this->sharkNodes[1].Y = 349 << 8;
    this->sharkNodes[1].AddNeighbour(2);
    this->sharkNodes[1].AddNeighbour(0);
    this->sharkNodes[1].AddNeighbour(4);
    
    this->sharkNodes[2].X = 698 << 8;
    this->sharkNodes[2].Y = 236 << 8;
    this->sharkNodes[2].AddNeighbour(3);
    this->sharkNodes[2].AddNeighbour(1);
    
    this->sharkNodes[3].X = 731 << 8;
    this->sharkNodes[3].Y = 143 << 8;
    this->sharkNodes[3].AddNeighbour(2);
    this->sharkNodes[3].AddNeighbour(6);
    this->sharkNodes[3].AddNeighbour(7);
    
    this->sharkNodes[4].X = 818 << 8;
    this->sharkNodes[4].Y = 398 << 8;
    this->sharkNodes[4].AddNeighbour(5);
    this->sharkNodes[4].AddNeighbour(1);
    
    this->sharkNodes[5].X = 888 << 8;
    this->sharkNodes[5].Y = 416 << 8;
    this->sharkNodes[5].AddNeighbour(4);
    
    this->sharkNodes[6].X = 880 << 8;
    this->sharkNodes[6].Y = 107 << 8;
    this->sharkNodes[6].AddNeighbour(3);
    
    this->sharkNodes[7].X = 648 << 8;
    this->sharkNodes[7].Y = 148 << 8;
    this->sharkNodes[7].AddNeighbour(3);
    
}
