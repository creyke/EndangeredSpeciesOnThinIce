// All code Copyright © 2010 Mobile Asylum
//   Level generated with EndangeredEd v1.0.1.0
//
// Level Name:          Cold Feet Retreat
// Level Author(s):     Dean Leeks
// Build Date/Time:     16/03/2010 03:17:16
// Map File Location:   "C:\Working\Projects\game\Editor\EndangeredEd\bin\x86\Debug\Levels"
// Map File Name:       "Level3-ColdFeetRetreat.esl"
//

#pragma once

#include "MA_LevelDescription.h"

class MA_Level3 : public MA_LevelDescription
{
public:
    MA_Level3();
};

