#include "MA_LevelContainer.h"

int MA_LevelContainer::levelCount = 0;

MA_LevelDescription* MA_LevelContainer::levels[maxLevels] = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0};

MA_LevelResult* MA_LevelContainer::levelResults[maxLevels] = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0};

s8 MA_LevelContainer::lastCompletedLevel = -1;
s8 MA_LevelContainer::lastAttemptedLevel = -1;

MA_LevelResult*  MA_LevelContainer::lastLevelResult = 0;


void MA_LevelContainer::AddLevel(MA_LevelDescription* level)
{
	if (levelCount < maxLevels)
	{
		levels[levelCount++] = level;
	}
}
MA_LevelDescription* MA_LevelContainer::GetLevel(int index)
{
	return levels[index];
}	
int MA_LevelContainer::GetLevelCount()
{
	return levelCount;
}
s8 MA_LevelContainer::GetLevelIndex(MA_LevelDescription* level)
{
	for (s8 i = 0; i < maxLevels; i++)
	{
		if (levels[i] == level)
		{
			return i;
		}
	}
	return -1;
}	
void MA_LevelContainer::SetNewLevelResult(MA_LevelResult* result)
{
	lastLevelResult = result;
	lastAttemptedLevel = result->GetLevelIndex();
	if (levelResults[lastAttemptedLevel] == 0)
	{
		levelResults[lastAttemptedLevel] = result;
		if (result->GetAward() < LevelAward_None)
		{
			lastCompletedLevel = lastAttemptedLevel; 
		}
	}
	else if (MA_LevelResult::Compare(result, levelResults[lastAttemptedLevel]) == -1)
	{
		levelResults[lastAttemptedLevel] = result;
	}
}
MA_LevelResult* MA_LevelContainer::GetLastLevelResult()
{
	return lastLevelResult;
}
MA_LevelResult* MA_LevelContainer::GetLevelResult(u8 levelIndex)
{
	if (levelIndex < maxLevels)
	{
		return levelResults[levelIndex];
	}
	return 0;
}
s8 MA_LevelContainer::GetLastCompletedLevel()
{
	return lastCompletedLevel;
}

// Gets the last level the player attempted, regardless of the result
s8 MA_LevelContainer::GetLastAttemptedLevel()
{
	return lastAttemptedLevel;
}
void MA_LevelContainer::SetLastAttemptedLevel(s8 levelIndex)
{
	lastAttemptedLevel = levelIndex;
}