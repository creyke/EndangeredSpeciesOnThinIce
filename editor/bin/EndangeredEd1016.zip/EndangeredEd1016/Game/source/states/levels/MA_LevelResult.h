#include "..\..\MA_Shared.h"

#pragma once

class MA_LevelResult
{
private:
	// The level that was attempted.
	u8 levelIndex;
	// level result: amount of seconds elapsed since start of game 
	u8 resultElapSecs;
	// level result: amount of minutes elapsed since start of game 
	u8 resultElapMins;
	// level result: amount of fish collected
	u16 resultFishCollected;
	// The award that this result was worth
	u8 award;
	// Calculates the award that this result was worth
	u8 CalculateAward();
	// Time taken in seconds
	u16 totalElapsedSecs;
public:
	MA_LevelResult(u8 levelIndex, u8 resultElapSecs, u8 resultElapMins, u16 resultFishCollected);
	// Gets the level that was attempted.
	u8 GetLevelIndex();
	// Gets Time taken in seconds
	u16 GetTotalElapsedSecs();
	// Gets the amount of seconds elapsed since start of game 
	u8 GetResultElapSecs();
	// Gets the amount of minutes elapsed since start of game 
	u8 GetResultElapMins();
	// Gets the amount of fish collected
	u16 GetResultFishCollected();
	// Gets the award that this result was worth
	u8 GetAward();
	// Compares two results. Return 0 == the same, 1 == result2 better, -1 == results1 better
	static s8 Compare(MA_LevelResult* result1, MA_LevelResult* result2);
	static bool Equals(MA_LevelResult* result1, MA_LevelResult* result2);
};