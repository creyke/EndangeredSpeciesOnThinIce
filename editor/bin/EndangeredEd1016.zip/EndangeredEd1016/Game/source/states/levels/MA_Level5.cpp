// All code Copyright © 2010 Mobile Asylum
//   Level generated with EndangeredEd v1.0.1.0
//
// Level Name:          Give me a name
// Level Author(s):     George Daters
// Build Date/Time:     10/03/2010 01:07:05
// Map File Location:   "C:\Working\Projects\game\Editor\EndangeredEd\bin\x86\Debug\Levels"
// Map File Name:       "Level5-NoName.esl"
//

#include "MA_LevelContainer.h"
#include "MA_Level5.h"
#include "all_gfx.h"

MA_Level5::MA_Level5() : MA_LevelDescription()
{
    // NB all coordinates are (x<<8)
    this->levelName = "Give me a name";
    
    // Set the dimension of the level
    this->levelWidth = 1024<<8;
    this->levelHeight = 1024<<8;
    
    // Define the goal requirements for pickups (gold, silver, bronze)
    this->pickupRequirements[0] = 20;
    this->pickupRequirements[1] = 25;
    this->pickupRequirements[2] = 15;
    
    // Define the time allowance in seconds for gold, silver, bronze
    this->totalTimeRequirements[0] = 0;
    this->totalTimeRequirements[1] = 0;
    this->totalTimeRequirements[2] = 0;
    
    // Add some tiles (xPos, yPos, tileIndex, moving, moveVectorX, movevectorY, movespeed)
    this->CreateTileSet(13<<8, 17<<8, 0, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(381<<8, 293<<8, 8, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(78<<8, 13<<8, 3, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(250<<8, 294<<8, 9, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(54<<8, 241<<8, 9, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(5<<8, 472<<8, 9, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(346<<8, 572<<8, 0, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(331<<8, 400<<8, 1, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(56<<8, 336<<8, 5, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(709<<8, 66<<8, 7, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(793<<8, 310<<8, 9, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(416<<8, 79<<8, 9, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(397<<8, 141<<8, 1, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(336<<8, 114<<8, 0, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(308<<8, 493<<8, 9, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(72<<8, 460<<8, 1, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(547<<8, 592<<8, 5, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(513<<8, 255<<8, 9, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(42<<8, 537<<8, 0, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(3<<8, 602<<8, 1, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(306<<8, 621<<8, 1, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(13<<8, 682<<8, 9, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(46<<8, 741<<8, 5, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(161<<8, 831<<8, 1, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(666<<8, 257<<8, 1, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(484<<8, 16<<8, 5, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(667<<8, 550<<8, 9, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(673<<8, 430<<8, 9, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(739<<8, 450<<8, 1, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(827<<8, 461<<8, 0, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(924<<8, 502<<8, 0, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(493<<8, 675<<8, 9, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(664<<8, 708<<8, 0, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(740<<8, 711<<8, 5, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(272<<8, 716<<8, 0, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(333<<8, 786<<8, 9, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(642<<8, 51<<8, 1, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(488<<8, 894<<8, 0, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(402<<8, 854<<8, 1, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(566<<8, 838<<8, 9, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(936<<8, 19<<8, 1, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(335<<8, 262<<8, 1, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(944<<8, 188<<8, 9, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(192<<8, 921<<8, 0, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(217<<8, 499<<8, 0, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(139<<8, 504<<8, 9, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(879<<8, 916<<8, 6, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(852<<8, 847<<8, 9, false, 0<<8, 0<<8, 1);
    
    // Add pickups
    this->AddCollectable(266<<8, 66<<8, 14<<8, 20<<8, (void*)fishjump_Sprite, OBJ_SIZE_32X32);
    this->AddCollectable(833<<8, 194<<8, 14<<8, 20<<8, (void*)fishjump_Sprite, OBJ_SIZE_32X32);
    this->AddCollectable(170<<8, 228<<8, 14<<8, 20<<8, (void*)fishjump_Sprite, OBJ_SIZE_32X32);
    this->AddCollectable(552<<8, 77<<8, 14<<8, 20<<8, (void*)fishjump_Sprite, OBJ_SIZE_32X32);
    this->AddCollectable(110<<8, 803<<8, 14<<8, 20<<8, (void*)fishjump_Sprite, OBJ_SIZE_32X32);
    this->AddCollectable(968<<8, 530<<8, 14<<8, 20<<8, (void*)fishjump_Sprite, OBJ_SIZE_32X32);
    this->AddCollectable(117<<8, 403<<8, 14<<8, 20<<8, (void*)fishjump_Sprite, OBJ_SIZE_32X32);
    this->AddCollectable(809<<8, 783<<8, 14<<8, 20<<8, (void*)fishjump_Sprite, OBJ_SIZE_32X32);
    this->AddCollectable(952<<8, 547<<8, 14<<8, 20<<8, (void*)fishjump_Sprite, OBJ_SIZE_32X32);
    this->AddCollectable(430<<8, 389<<8, 14<<8, 20<<8, (void*)fishjump_Sprite, OBJ_SIZE_32X32);
    this->AddCollectable(301<<8, 748<<8, 14<<8, 20<<8, (void*)fishjump_Sprite, OBJ_SIZE_32X32);
    this->AddCollectable(572<<8, 567<<8, 14<<8, 20<<8, (void*)fishjump_Sprite, OBJ_SIZE_32X32);
    this->AddCollectable(523<<8, 724<<8, 14<<8, 20<<8, (void*)fishjump_Sprite, OBJ_SIZE_32X32);
    this->AddCollectable(520<<8, 929<<8, 14<<8, 20<<8, (void*)fishjump_Sprite, OBJ_SIZE_32X32);
    this->AddCollectable(701<<8, 295<<8, 14<<8, 20<<8, (void*)fishjump_Sprite, OBJ_SIZE_32X32);
    this->AddCollectable(636<<8, 355<<8, 14<<8, 20<<8, (void*)fishjump_Sprite, OBJ_SIZE_32X32);
    this->AddCollectable(968<<8, 54<<8, 14<<8, 20<<8, (void*)fishjump_Sprite, OBJ_SIZE_32X32);
    this->AddCollectable(75<<8, 566<<8, 14<<8, 20<<8, (void*)fishjump_Sprite, OBJ_SIZE_32X32);
    this->AddCollectable(959<<8, 962<<8, 14<<8, 20<<8, (void*)fishjump_Sprite, OBJ_SIZE_32X32);
    this->AddCollectable(940<<8, 985<<8, 14<<8, 20<<8, (void*)fishjump_Sprite, OBJ_SIZE_32X32);
    this->AddCollectable(997<<8, 974<<8, 14<<8, 20<<8, (void*)fishjump_Sprite, OBJ_SIZE_32X32);
    this->AddCollectable(981<<8, 992<<8, 14<<8, 20<<8, (void*)fishjump_Sprite, OBJ_SIZE_32X32);
    this->AddCollectable(954<<8, 1012<<8, 14<<8, 20<<8, (void*)fishjump_Sprite, OBJ_SIZE_32X32);
    this->AddCollectable(996<<8, 1011<<8, 14<<8, 20<<8, (void*)fishjump_Sprite, OBJ_SIZE_32X32);
    this->AddCollectable(946<<8, 521<<8, 14<<8, 20<<8, (void*)fishjump_Sprite, OBJ_SIZE_32X32);
    
    // Add signs
    this->AddSign(228<<8, 944<<8, 35<<8, 52<<8, (void*)sign_3_Sprite, OBJ_SIZE_64X64, "Wrong way!");
    this->AddSign(257<<8, 193<<8, 35<<8, 52<<8, (void*)sign_3_Sprite, OBJ_SIZE_64X64, "Danger! Sharks!");
    this->AddSign(787<<8, 805<<8, 35<<8, 52<<8, (void*)sign_3_Sprite, OBJ_SIZE_64X64, "I hope you're hungry!");
    
    // Add checkpoints
    this->AddCheckpoint(520<<8, 419<<8, 30<<8, 50<<8, (void*)snowman_Sprite, OBJ_SIZE_64X64);
    
    // Add penguin
    this->AddPenguin(43<<8, 54<<8);
    //this->AddStartGate(43<<8, 54<<8);

    // Create shark nodes - make sure to give the nodes neighbours otherwise the shark will get stuck
    this->sharkNodeCount = 24;
    
    // Create an array of nodes
    this->sharkNodes = new MA_Node[this->sharkNodeCount];
    
    this->sharkNodes[0].X = 319 << 8;
    this->sharkNodes[0].Y = 387 << 8;
    this->sharkNodes[0].AddNeighbour(1);
    
    this->sharkNodes[1].X = 346 << 8;
    this->sharkNodes[1].Y = 355 << 8;
    this->sharkNodes[1].AddNeighbour(0);
    this->sharkNodes[1].AddNeighbour(2);
    
    this->sharkNodes[2].X = 385 << 8;
    this->sharkNodes[2].Y = 339 << 8;
    this->sharkNodes[2].AddNeighbour(1);
    this->sharkNodes[2].AddNeighbour(3);
    
    this->sharkNodes[3].X = 418 << 8;
    this->sharkNodes[3].Y = 295 << 8;
    this->sharkNodes[3].AddNeighbour(2);
    this->AddShark(3);
    
    this->sharkNodes[4].X = 204 << 8;
    this->sharkNodes[4].Y = 286 << 8;
    this->sharkNodes[4].AddNeighbour(5);
    this->AddShark(4);
    
    this->sharkNodes[5].X = 267 << 8;
    this->sharkNodes[5].Y = 278 << 8;
    this->sharkNodes[5].AddNeighbour(4);
    this->sharkNodes[5].AddNeighbour(6);
    
    this->sharkNodes[6].X = 324 << 8;
    this->sharkNodes[6].Y = 266 << 8;
    this->sharkNodes[6].AddNeighbour(5);
    this->sharkNodes[6].AddNeighbour(7);
    
    this->sharkNodes[7].X = 357 << 8;
    this->sharkNodes[7].Y = 227 << 8;
    this->sharkNodes[7].AddNeighbour(6);
    
    this->sharkNodes[8].X = 810 << 8;
    this->sharkNodes[8].Y = 462 << 8;
    this->sharkNodes[8].AddNeighbour(15);
    this->sharkNodes[8].AddNeighbour(9);
    this->AddShark(8);
    
    this->sharkNodes[9].X = 808 << 8;
    this->sharkNodes[9].Y = 512 << 8;
    this->sharkNodes[9].AddNeighbour(10);
    this->sharkNodes[9].AddNeighbour(8);
    
    this->sharkNodes[10].X = 825 << 8;
    this->sharkNodes[10].Y = 553 << 8;
    this->sharkNodes[10].AddNeighbour(11);
    this->sharkNodes[10].AddNeighbour(9);
    
    this->sharkNodes[11].X = 872 << 8;
    this->sharkNodes[11].Y = 555 << 8;
    this->sharkNodes[11].AddNeighbour(12);
    this->sharkNodes[11].AddNeighbour(10);
    
    this->sharkNodes[12].X = 903 << 8;
    this->sharkNodes[12].Y = 533 << 8;
    this->sharkNodes[12].AddNeighbour(13);
    this->sharkNodes[12].AddNeighbour(11);
    
    this->sharkNodes[13].X = 917 << 8;
    this->sharkNodes[13].Y = 487 << 8;
    this->sharkNodes[13].AddNeighbour(14);
    this->sharkNodes[13].AddNeighbour(12);
    
    this->sharkNodes[14].X = 899 << 8;
    this->sharkNodes[14].Y = 438 << 8;
    this->sharkNodes[14].AddNeighbour(15);
    this->sharkNodes[14].AddNeighbour(13);
    
    this->sharkNodes[15].X = 841 << 8;
    this->sharkNodes[15].Y = 433 << 8;
    this->sharkNodes[15].AddNeighbour(8);
    this->sharkNodes[15].AddNeighbour(14);
    
    this->sharkNodes[16].X = 808 << 8;
    this->sharkNodes[16].Y = 884 << 8;
    this->sharkNodes[16].AddNeighbour(17);
    this->sharkNodes[16].AddNeighbour(20);
    
    this->sharkNodes[17].X = 830 << 8;
    this->sharkNodes[17].Y = 846 << 8;
    this->sharkNodes[17].AddNeighbour(16);
    this->sharkNodes[17].AddNeighbour(18);
    this->AddShark(17);
    
    this->sharkNodes[18].X = 883 << 8;
    this->sharkNodes[18].Y = 823 << 8;
    this->sharkNodes[18].AddNeighbour(17);
    this->sharkNodes[18].AddNeighbour(19);
    
    this->sharkNodes[19].X = 927 << 8;
    this->sharkNodes[19].Y = 826 << 8;
    this->sharkNodes[19].AddNeighbour(18);
    this->sharkNodes[19].AddNeighbour(23);
    
    this->sharkNodes[20].X = 833 << 8;
    this->sharkNodes[20].Y = 918 << 8;
    this->sharkNodes[20].AddNeighbour(21);
    this->sharkNodes[20].AddNeighbour(16);
    
    this->sharkNodes[21].X = 875 << 8;
    this->sharkNodes[21].Y = 935 << 8;
    this->sharkNodes[21].AddNeighbour(22);
    this->sharkNodes[21].AddNeighbour(20);
    
    this->sharkNodes[22].X = 938 << 8;
    this->sharkNodes[22].Y = 901 << 8;
    this->sharkNodes[22].AddNeighbour(23);
    this->sharkNodes[22].AddNeighbour(21);
    this->AddShark(22);
    
    this->sharkNodes[23].X = 954 << 8;
    this->sharkNodes[23].Y = 864 << 8;
    this->sharkNodes[23].AddNeighbour(19);
    this->sharkNodes[23].AddNeighbour(22);
    
}
