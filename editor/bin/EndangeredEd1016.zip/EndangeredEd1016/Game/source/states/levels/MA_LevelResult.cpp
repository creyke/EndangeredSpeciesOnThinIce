#include "MA_LevelResult.h"
#include "MA_LevelContainer.h"

MA_LevelResult::MA_LevelResult(u8 levelIndex, u8 resultElapSecs, u8 resultElapMins, u16 resultFishCollected)
{
	this->levelIndex = levelIndex;
	this->resultElapSecs = resultElapSecs;
	this->resultElapMins = resultElapMins;
	this->resultFishCollected = resultFishCollected;
	this->totalElapsedSecs = resultElapMins * 60 + resultElapSecs;
	this->award = this->CalculateAward();
}
u8 MA_LevelResult::CalculateAward()
{
	u8 levelAward = 3;

	if (this->levelIndex < MA_LevelContainer::maxLevels)
	{
		for (s8 i = 2; i >= 0; i--)
		{
			//if (this->resultFishCollected >= MA_LevelContainer::GetLevel(this->levelIndex)->GetPickupRequirement(i) &&
			//	this->totalElapsedSecs <= MA_LevelContainer::GetLevel(this->levelIndex)->GetTimeRequirement(i))
			//{
			//	levelAward = (u8)i;
			//}

			// Note check on time is disabled as none of the levels have times in them
			if (this->resultFishCollected >= MA_LevelContainer::GetLevel(this->levelIndex)->GetPickupRequirement(i))
			{
				levelAward = (u8)i;
			}
		}
	}
	return levelAward;
}

// Gets the level that was attempted.
u8 MA_LevelResult::GetLevelIndex()
{
	return this->levelIndex;	
}
// Gets the amount of seconds elapsed since start of game 
u8 MA_LevelResult::GetResultElapSecs()
{
	return this->resultElapSecs;
}
// Gets the amount of minutes elapsed since start of game 
u8 MA_LevelResult::GetResultElapMins()
{
	return this->resultElapMins;
}
	// Gets Time taken in seconds
u16 MA_LevelResult::GetTotalElapsedSecs()
{
	return this->totalElapsedSecs;
}
// Gets the amount of fish collected
u16 MA_LevelResult::GetResultFishCollected()
{
	return this->resultFishCollected;
}
// Gets the award that this result was worth
u8 MA_LevelResult::GetAward()
{
	return this->award;
}
bool MA_LevelResult::Equals(MA_LevelResult* result1, MA_LevelResult* result2)
{
	return result1->resultFishCollected == result2->resultFishCollected &&
			result1->totalElapsedSecs == result2->totalElapsedSecs;
}
// Compares two results. Return 0 == the same, 1 == result2 better, -1 == results1 better
s8 MA_LevelResult::Compare(MA_LevelResult* result1, MA_LevelResult* result2)
{
	if (Equals(result1, result2))
		return 0;
	else
	{
		if (result1->award == result2->award)
		{
			if (result1->resultFishCollected > result2->resultFishCollected)
			{
				return -1;
			}
			else if (result1->resultFishCollected < result2->resultFishCollected)
			{
				return 1;
			}
			else
			{
				if (result1->totalElapsedSecs < result2->totalElapsedSecs)
				{
					return -1;
				}
				else
				{
					return 1;
				}
			}
		}
		else
		{
			if (result1->award < result2->award)
			{
				return -1;
			}
			else
			{
				return 1;
			}
		}
	}
}