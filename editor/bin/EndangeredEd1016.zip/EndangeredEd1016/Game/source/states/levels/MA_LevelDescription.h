#include "..\..\MA_Shared.h"
#include <string>
#include "..\..\entities\MA_Node.h"

#pragma once

class MA_EntityDescription;


using std::string;

class MA_LevelDescription
{
protected:

	const static s32 mapTileSize = 64<<8;
	const static s32 mapTileSizeOverTwo = 32<<8;
	const static u32 maxRandomTileMove = (80<<8);
	const static u32 minRandomTileMove = (10<<8);

	string levelName;

	// The amount of pickups required for gold [0], silver [1] and bronze [2]
	u16 pickupRequirements[3];
	// The amount of seconds to beat for gold [0], silver [1] and bronze [2]
	u16 totalTimeRequirements[3];

	// A dynamic array of all the level shark nodes
	MA_Node* sharkNodes;
	// The number of shark nodes in this map
	int sharkNodeCount;

	MA_EntityDescription* entities[800];
	s32 levelWidth;
	s32 levelHeight;
	u16 entityCount;
	u16 pickupCount;
	u16 signCount;
	u16 checkpointCount;
	u16 iceBlockCount;
	u16 tileCount;
	u16 sharkCount;

	MA_EntityDescription* tiles[400];


	void AddEnvironmentEntity(s32 x, s32 y, u8 environmentID);
	void AddSign(s32 x, s32 y, string signText, u8 signFrame);
	void AddSign(s32 x, s32 y, s32 offsetX, s32 offsetY, void* spriteData, u8 shape, u8 size, string txt);
	void AddCollectable(s32 x, s32 y, s32 offsetX, s32 offsetY, void* spriteData, u8 shape, u8 size);
	void AddCheckpoint(s32 x, s32 y, s32 offsetX, s32 offsetY,void* spriteData, u8 shape, u8 size);
	void AddTile(s32 x, s32 y, u8 tileIndex, bool isMoving, s32 moveVectorX, s32 moveVectorY, s32 moveSpeed); 
	void AddIceBlock(s32 x, s32 y);
	void AddPenguin(s32 x, s32 y);
	void AddPolarBear(s32 x, s32 y);
	void AddShark(u16 sharkNodeIndex);
	void AddStartGate(s32 x, s32 y);
	void AddFinishGate(s32 x, s32 y);
	// Used for random maps - creates collectables randomly on map tiles
	void CreateRandomCollectables();
	// Used for random maps - creates checkpoints randmoly on map tiles
	void CreateRandomCheckpoints();	
	void CreateRandomMapTiles(u16 totalTiles);
	// Helper function that creates a group of tiles with the top left corner being at the x and y index
	void CreateTileSet(s32 x, s32 y, u8 tileGroupIndex, bool isMoving, s32 moveVectorX, s32 moveVectorY, s32 moveSpeed);

public:
	string GetLevelName();
	//MA_EntityDescription* GetEntities();
	MA_EntityDescription* GetEntity(int index);
	s32 GetLevelWidth();
	s32 GetLevelHeight();
	u16 GetEntityCount();
	u16 GetPickupCount();
	u16 GetCheckpointCount();
	u16 GetTileCount();
	u16 GetSignCount();
	u16 GetSharkCount();
	MA_Node* GetSharkNodes();
	int GetSharkNodeCount();
	MA_LevelDescription();
	static MA_LevelDescription* CreateRandomMap(u16 tileCount);
	// Returns the time requirement to get gold (0), silver (1) or bronze (2) when completing the level
	u16 GetTimeRequirement(int awardIndex);
	// Returns the pickups requirement to get gold (0), silver (1) or bronze (2) when completing the level
	u16 GetPickupRequirement(int awardIndex);


};