// All code Copyright © 2010 Mobile Asylum
//   Level generated with EndangeredEd v1.0.1.2
//
// Level Name:          Tile Demo
// Level Author(s):     gsd
// Build Date/Time:     26/03/2010 15:34:42
// Map File Location:   "C:\working\projects\game\Editor\EndangeredEd\bin\x86\Debug\Levels"
// Map File Name:       "LevelTemplate.esl"
//

#include "MA_LevelContainer.h"
#include "MA_Level6.h"
#include "all_gfx.h"

MA_Level6::MA_Level6() : MA_LevelDescription()
{
    // NB all coordinates are (x<<8)
    this->levelName = "Tile Demo";
    
    // Set the dimension of the level
    this->levelWidth = 1200<<8;
    this->levelHeight = 800<<8;
    
    // Define the goal requirements for pickups (gold, silver, bronze)
    this->pickupRequirements[0] = 10;
    this->pickupRequirements[1] = 11;
    this->pickupRequirements[2] = 9;
    
    // Define the time allowance in seconds for gold, silver, bronze
    this->totalTimeRequirements[0] = 0;
    this->totalTimeRequirements[1] = 0;
    this->totalTimeRequirements[2] = 0;
    
    // Add some tiles (xPos, yPos, tileIndex, moving, moveVectorX, movevectorY, movespeed)
    this->CreateTileSet(25<<8, 53<<8, 0, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(128<<8, 36<<8, 1, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(214<<8, 22<<8, 3, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(17<<8, 141<<8, 5, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(752<<8, 528<<8, 6, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(867<<8, 92<<8, 7, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(-80<<8, 335<<8, 8, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(141<<8, 143<<8, 9, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(490<<8, 628<<8, 10, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(798<<8, 357<<8, 11, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(307<<8, 299<<8, 12, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(495<<8, 425<<8, 13, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(496<<8, 46<<8, 14, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(677<<8, -12<<8, 15, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(684<<8, 162<<8, 16, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(617<<8, 306<<8, 17, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(446<<8, 360<<8, 18, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(612<<8, 182<<8, 19, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(314<<8, 580<<8, 20, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(713<<8, 459<<8, 21, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(647<<8, 582<<8, 22, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(922<<8, 348<<8, 23, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(809<<8, 281<<8, 24, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(234<<8, 392<<8, 25, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(230<<8, 596<<8, 26, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(406<<8, 624<<8, 27, false, 0<<8, 0<<8, 1);
    
    // Add pickups
    this->AddCollectable(83<<8, 214<<8, 16<<8, 20<<8, (void*)fishjump_Sprite, OBJ_SIZE_32X32);
    this->AddCollectable(38<<8, 454<<8, 16<<8, 20<<8, (void*)fishjump_Sprite, OBJ_SIZE_32X32);
    this->AddCollectable(160<<8, 582<<8, 16<<8, 20<<8, (void*)fishjump_Sprite, OBJ_SIZE_32X32);
    this->AddCollectable(341<<8, 599<<8, 16<<8, 20<<8, (void*)fishjump_Sprite, OBJ_SIZE_32X32);
    this->AddCollectable(543<<8, 678<<8, 16<<8, 20<<8, (void*)fishjump_Sprite, OBJ_SIZE_32X32);
    this->AddCollectable(542<<8, 482<<8, 16<<8, 20<<8, (void*)fishjump_Sprite, OBJ_SIZE_32X32);
    this->AddCollectable(844<<8, 620<<8, 16<<8, 20<<8, (void*)fishjump_Sprite, OBJ_SIZE_32X32);
    this->AddCollectable(1039<<8, 153<<8, 16<<8, 20<<8, (void*)fishjump_Sprite, OBJ_SIZE_32X32);
    this->AddCollectable(708<<8, 57<<8, 16<<8, 20<<8, (void*)fishjump_Sprite, OBJ_SIZE_32X32);
    this->AddCollectable(713<<8, 340<<8, 16<<8, 20<<8, (void*)fishjump_Sprite, OBJ_SIZE_32X32);
    this->AddCollectable(356<<8, 406<<8, 16<<8, 20<<8, (void*)fishjump_Sprite, OBJ_SIZE_32X32);
    
    // Add signs
    
    // Add checkpoints
    
    // Add penguin
    this->AddPenguin(347<<8, 159<<8);
    
    // Create shark nodes - make sure to give the nodes neighbours otherwise the shark will get stuck
    this->sharkNodeCount = 0;
    
    // Create an array of nodes
    this->sharkNodes = new MA_Node[this->sharkNodeCount];
    
}
