#include "MA_EntityDescription.h"

MA_EntityDescription::MA_EntityDescription(EntityType eType,
			s32 x, s32 y, s32 offsetX, s32 offsetY, void* spriteData, u8 shape, u8 size, u8 paletteID)
{
	this->eType = eType;
	this->x = x;
	this->y = y;
	this->offsetX = offsetX;
	this->offsetY = offsetY;
	this->spriteData = spriteData;
	this->shape = shape;
	this->size = size;
	this->paletteID = paletteID;
}