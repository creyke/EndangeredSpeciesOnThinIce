// All code Copyright © 2010 Mobile Asylum
//   Level generated with EndangeredEd v1.0.1.0
//
// Level Name:          Snow Joke
// Level Author(s):     Roger Creyke
// Build Date/Time:     09/03/2010 23:11:49
// Map File Location:   "C:\Working\Projects\Game\Editor\EndangeredEd\bin\x86\Debug\Levels"
// Map File Name:       "Level4-SnowJoke.esl"
//

#include "MA_LevelContainer.h"
#include "MA_Level4.h"
#include "all_gfx.h"

MA_Level4::MA_Level4() : MA_LevelDescription()
{
    // NB all coordinates are (x<<8)
    this->levelName = "Snow Joke";
    
    // Set the dimension of the level
    this->levelWidth = 1024<<8;
    this->levelHeight = 512<<8;
    
    // Define the goal requirements for pickups (gold, silver, bronze)
    this->pickupRequirements[0] = 0;
    this->pickupRequirements[1] = 0;
    this->pickupRequirements[2] = 0;
    
    // Define the time allowance in seconds for gold, silver, bronze
    this->totalTimeRequirements[0] = 0;
    this->totalTimeRequirements[1] = 0;
    this->totalTimeRequirements[2] = 0;
    
    // Add some tiles (xPos, yPos, tileIndex, moving, moveVectorX, movevectorY, movespeed)
    this->CreateTileSet(191<<8, 425<<8, 3, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(585<<8, 347<<8, 5, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(-100<<8, -100<<8, 3, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(323<<8, 125<<8, 7, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(861<<8, 298<<8, 8, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(90<<8, 147<<8, 9, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(120<<8, 398<<8, 9, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(156<<8, 276<<8, 5, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(-120<<8, 181<<8, 7, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(745<<8, 247<<8, 5, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(729<<8, 10<<8, 5, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(886<<8, -130<<8, 3, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(579<<8, 54<<8, 5, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(496<<8, 57<<8, 9, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(397<<8, 382<<8, 9, false, 0<<8, 0<<8, 1);
    
    // Add pickups
    this->AddCollectable(105<<8, 113<<8, 14<<8, 20<<8, (void*)fishjump_Sprite, OBJ_SIZE_32X32);
    this->AddCollectable(957<<8, 33<<8, 14<<8, 20<<8, (void*)fishjump_Sprite, OBJ_SIZE_32X32);
    this->AddCollectable(650<<8, 415<<8, 14<<8, 20<<8, (void*)fishjump_Sprite, OBJ_SIZE_32X32);
    this->AddCollectable(303<<8, 493<<8, 14<<8, 20<<8, (void*)fishjump_Sprite, OBJ_SIZE_32X32);
    this->AddCollectable(395<<8, 173<<8, 14<<8, 20<<8, (void*)fishjump_Sprite, OBJ_SIZE_32X32);
    
    // Add signs
    this->AddSign(376<<8, 331<<8, 35<<8, 52<<8, (void*)sign_3_Sprite, OBJ_SIZE_64X64, "There are 5 fish in this level.");
    this->AddSign(952<<8, 101<<8, 35<<8, 52<<8, (void*)sign_3_Sprite, OBJ_SIZE_64X64, "You found a secret place!");
    
    // Add checkpoints
    this->AddCheckpoint(769<<8, 45<<8, 30<<8, 50<<8, (void*)snowman_Sprite, OBJ_SIZE_64X64);
    
    // Add penguin
    this->AddPenguin(52<<8, 67<<8);
    this->AddStartGate(52<<8, 67<<8);

    // Create shark nodes - make sure to give the nodes neighbours otherwise the shark will get stuck
    this->sharkNodeCount = 17;
    
    // Create an array of nodes
    this->sharkNodes = new MA_Node[this->sharkNodeCount];
    
    this->sharkNodes[0].X = 700 << 8;
    this->sharkNodes[0].Y = 309 << 8;
    this->sharkNodes[0].AddNeighbour(6);
    this->sharkNodes[0].AddNeighbour(1);
    this->sharkNodes[0].AddNeighbour(2);
    this->AddShark(0);
    
    this->sharkNodes[1].X = 625 << 8;
    this->sharkNodes[1].Y = 229 << 8;
    this->sharkNodes[1].AddNeighbour(0);
    this->sharkNodes[1].AddNeighbour(6);
    this->sharkNodes[1].AddNeighbour(2);
    
    this->sharkNodes[2].X = 751 << 8;
    this->sharkNodes[2].Y = 198 << 8;
    this->sharkNodes[2].AddNeighbour(1);
    this->sharkNodes[2].AddNeighbour(0);
    this->sharkNodes[2].AddNeighbour(6);
    this->sharkNodes[2].AddNeighbour(3);
    this->sharkNodes[2].AddNeighbour(5);
    this->sharkNodes[2].AddNeighbour(4);
    
    this->sharkNodes[3].X = 877 << 8;
    this->sharkNodes[3].Y = 198 << 8;
    this->sharkNodes[3].AddNeighbour(2);
    this->sharkNodes[3].AddNeighbour(4);
    this->sharkNodes[3].AddNeighbour(5);
    
    this->sharkNodes[4].X = 982 << 8;
    this->sharkNodes[4].Y = 276 << 8;
    this->sharkNodes[4].AddNeighbour(3);
    this->sharkNodes[4].AddNeighbour(5);
    this->sharkNodes[4].AddNeighbour(2);
    
    this->sharkNodes[5].X = 985 << 8;
    this->sharkNodes[5].Y = 164 << 8;
    this->sharkNodes[5].AddNeighbour(4);
    this->sharkNodes[5].AddNeighbour(3);
    this->sharkNodes[5].AddNeighbour(2);
    this->AddShark(5);
    
    this->sharkNodes[6].X = 617 << 8;
    this->sharkNodes[6].Y = 296 << 8;
    this->sharkNodes[6].AddNeighbour(0);
    this->sharkNodes[6].AddNeighbour(1);
    this->sharkNodes[6].AddNeighbour(2);
    
    this->sharkNodes[7].X = 794 << 8;
    this->sharkNodes[7].Y = 417 << 8;
    this->sharkNodes[7].AddNeighbour(8);
    this->sharkNodes[7].AddNeighbour(9);
    
    this->sharkNodes[8].X = 746 << 8;
    this->sharkNodes[8].Y = 476 << 8;
    this->sharkNodes[8].AddNeighbour(7);
    this->sharkNodes[8].AddNeighbour(9);
    this->AddShark(8);
    
    this->sharkNodes[9].X = 839 << 8;
    this->sharkNodes[9].Y = 467 << 8;
    this->sharkNodes[9].AddNeighbour(8);
    this->sharkNodes[9].AddNeighbour(7);
    
    this->sharkNodes[10].X = 283 << 8;
    this->sharkNodes[10].Y = 129 << 8;
    this->sharkNodes[10].AddNeighbour(16);
    this->sharkNodes[10].AddNeighbour(14);
    this->sharkNodes[10].AddNeighbour(15);
    this->sharkNodes[10].AddNeighbour(12);
    this->sharkNodes[10].AddNeighbour(11);
    
    this->sharkNodes[11].X = 200 << 8;
    this->sharkNodes[11].Y = 242 << 8;
    this->sharkNodes[11].AddNeighbour(12);
    this->sharkNodes[11].AddNeighbour(16);
    this->sharkNodes[11].AddNeighbour(10);
    this->AddShark(11);
    
    this->sharkNodes[12].X = 292 << 8;
    this->sharkNodes[12].Y = 254 << 8;
    this->sharkNodes[12].AddNeighbour(13);
    this->sharkNodes[12].AddNeighbour(11);
    this->sharkNodes[12].AddNeighbour(10);
    this->sharkNodes[12].AddNeighbour(16);
    
    this->sharkNodes[13].X = 328 << 8;
    this->sharkNodes[13].Y = 413 << 8;
    this->sharkNodes[13].AddNeighbour(12);
    
    this->sharkNodes[14].X = 433 << 8;
    this->sharkNodes[14].Y = 91 << 8;
    this->sharkNodes[14].AddNeighbour(10);
    this->sharkNodes[14].AddNeighbour(16);
    this->sharkNodes[14].AddNeighbour(15);
    
    this->sharkNodes[15].X = 440 << 8;
    this->sharkNodes[15].Y = 34 << 8;
    this->sharkNodes[15].AddNeighbour(16);
    this->sharkNodes[15].AddNeighbour(10);
    this->sharkNodes[15].AddNeighbour(14);
    this->AddShark(15);
    
    this->sharkNodes[16].X = 193 << 8;
    this->sharkNodes[16].Y = 27 << 8;
    this->sharkNodes[16].AddNeighbour(10);
    this->sharkNodes[16].AddNeighbour(14);
    this->sharkNodes[16].AddNeighbour(15);
    this->sharkNodes[16].AddNeighbour(11);
    this->sharkNodes[16].AddNeighbour(12);
    
}
