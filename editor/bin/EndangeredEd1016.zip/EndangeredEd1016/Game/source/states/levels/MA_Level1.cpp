// All code Copyright © 2010 Mobile Asylum
//   Level generated with EndangeredEd v1.0.1.0
//
// Level Name:          Tenderfoot Pass
// Level Author(s):     Roger Creyke
// Build Date/Time:     16/03/2010 03:14:26
// Map File Location:   "C:\Working\Projects\game\Editor\EndangeredEd\bin\x86\Debug\Levels"
// Map File Name:       "Level1-TenderfootPass.esl"
//

#include "MA_LevelContainer.h"
#include "MA_Level1.h"
#include "all_gfx.h"

MA_Level1::MA_Level1() : MA_LevelDescription()
{
    // NB all coordinates are (x<<8)
    this->levelName = "Tenderfoot Pass";
    
    // Set the dimension of the level
    this->levelWidth = 512<<8;
    this->levelHeight = 512<<8;
    
    // Define the goal requirements for pickups (gold, silver, bronze)
    this->pickupRequirements[0] = 0;
    this->pickupRequirements[1] = 0;
    this->pickupRequirements[2] = 0;
    
    // Define the time allowance in seconds for gold, silver, bronze
    this->totalTimeRequirements[0] = 0;
    this->totalTimeRequirements[1] = 0;
    this->totalTimeRequirements[2] = 0;
    
    // Add some tiles (xPos, yPos, tileIndex, moving, moveVectorX, movevectorY, movespeed)
    this->CreateTileSet(253<<8, 248<<8, 0, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(95<<8, 212<<8, 0, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(326<<8, 194<<8, 0, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(167<<8, 268<<8, 0, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(236<<8, 18<<8, 0, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(39<<8, 139<<8, 0, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(374<<8, 129<<8, 0, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(415<<8, 344<<8, 0, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(348<<8, 278<<8, 0, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(32<<8, 390<<8, 0, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(315<<8, 63<<8, 0, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(98<<8, 331<<8, 0, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(363<<8, 410<<8, 0, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(285<<8, 438<<8, 0, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(187<<8, 445<<8, 0, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(134<<8, 11<<8, 0, false, 0<<8, 0<<8, 1);
    
    // Add pickups
    this->AddCollectable(134<<8, 235<<8, 16<<8, 20<<8, (void*)fishjump_Sprite, OBJ_SIZE_32X32);
    this->AddCollectable(261<<8, 43<<8, 16<<8, 20<<8, (void*)fishjump_Sprite, OBJ_SIZE_32X32);
    this->AddCollectable(450<<8, 367<<8, 16<<8, 20<<8, (void*)fishjump_Sprite, OBJ_SIZE_32X32);
    
    // Add signs
    this->AddSign(386<<8, 171<<8, 34<<8, 52<<8, (void*)sign_3_Sprite, OBJ_SIZE_64X64, "");
    this->AddSign(179<<8, 295<<8, 35<<8, 52<<8, (void*)sign_3_Sprite, OBJ_SIZE_64X64, "");
    this->AddSign(400<<8, 296<<8, 30<<8, 50<<8, (void*)sign_3_Sprite, OBJ_SIZE_64X64, "");
    
    // Add checkpoints
    this->AddCheckpoint(277<<8, 273<<8, 30<<8, 50<<8, (void*)snowman_Sprite, OBJ_SIZE_64X64);
    this->AddCheckpoint(417<<8, 150<<8, 30<<8, 50<<8, (void*)snowman_Sprite, OBJ_SIZE_64X64);
    this->AddCheckpoint(80<<8, 158<<8, 30<<8, 50<<8, (void*)snowman_Sprite, OBJ_SIZE_64X64);
    
    // Add penguin
    this->AddPenguin(187<<8, 307<<8);
    
    // Create shark nodes - make sure to give the nodes neighbours otherwise the shark will get stuck
    this->sharkNodeCount = 16;
    
    // Create an array of nodes
    this->sharkNodes = new MA_Node[this->sharkNodeCount];
    
    this->sharkNodes[0].X = 292 << 8;
    this->sharkNodes[0].Y = 94 << 8;
    this->sharkNodes[0].AddNeighbour(1);
    this->sharkNodes[0].AddNeighbour(2);
    this->sharkNodes[0].AddNeighbour(5);
    this->AddShark(0);
    
    this->sharkNodes[1].X = 326 << 8;
    this->sharkNodes[1].Y = 33 << 8;
    this->sharkNodes[1].AddNeighbour(0);
    this->sharkNodes[1].AddNeighbour(6);
    this->sharkNodes[1].AddNeighbour(4);
    
    this->sharkNodes[2].X = 330 << 8;
    this->sharkNodes[2].Y = 179 << 8;
    this->sharkNodes[2].AddNeighbour(3);
    this->sharkNodes[2].AddNeighbour(0);
    this->sharkNodes[2].AddNeighbour(4);
    
    this->sharkNodes[3].X = 473 << 8;
    this->sharkNodes[3].Y = 219 << 8;
    this->sharkNodes[3].AddNeighbour(4);
    this->sharkNodes[3].AddNeighbour(2);
    
    this->sharkNodes[4].X = 421 << 8;
    this->sharkNodes[4].Y = 71 << 8;
    this->sharkNodes[4].AddNeighbour(3);
    this->sharkNodes[4].AddNeighbour(2);
    this->sharkNodes[4].AddNeighbour(1);
    
    this->sharkNodes[5].X = 201 << 8;
    this->sharkNodes[5].Y = 71 << 8;
    this->sharkNodes[5].AddNeighbour(6);
    this->sharkNodes[5].AddNeighbour(0);
    
    this->sharkNodes[6].X = 253 << 8;
    this->sharkNodes[6].Y = 6 << 8;
    this->sharkNodes[6].AddNeighbour(1);
    this->sharkNodes[6].AddNeighbour(5);
    
    this->sharkNodes[7].X = 262 << 8;
    this->sharkNodes[7].Y = 438 << 8;
    this->sharkNodes[7].AddNeighbour(10);
    this->sharkNodes[7].AddNeighbour(8);
    this->AddShark(7);
    
    this->sharkNodes[8].X = 352 << 8;
    this->sharkNodes[8].Y = 426 << 8;
    this->sharkNodes[8].AddNeighbour(9);
    this->sharkNodes[8].AddNeighbour(7);
    this->AddShark(8);
    
    this->sharkNodes[9].X = 363 << 8;
    this->sharkNodes[9].Y = 507 << 8;
    this->sharkNodes[9].AddNeighbour(10);
    this->sharkNodes[9].AddNeighbour(8);
    this->AddShark(9);
    
    this->sharkNodes[10].X = 280 << 8;
    this->sharkNodes[10].Y = 508 << 8;
    this->sharkNodes[10].AddNeighbour(7);
    this->sharkNodes[10].AddNeighbour(9);
    this->AddShark(10);
    
    this->sharkNodes[11].X = 139 << 8;
    this->sharkNodes[11].Y = 107 << 8;
    this->sharkNodes[11].AddNeighbour(12);
    this->sharkNodes[11].AddNeighbour(14);
    
    this->sharkNodes[12].X = 274 << 8;
    this->sharkNodes[12].Y = 164 << 8;
    this->sharkNodes[12].AddNeighbour(13);
    this->sharkNodes[12].AddNeighbour(11);
    
    this->sharkNodes[13].X = 224 << 8;
    this->sharkNodes[13].Y = 221 << 8;
    this->sharkNodes[13].AddNeighbour(12);
    this->sharkNodes[13].AddNeighbour(14);
    this->sharkNodes[13].AddNeighbour(15);
    this->AddShark(13);
    
    this->sharkNodes[14].X = 158 << 8;
    this->sharkNodes[14].Y = 163 << 8;
    this->sharkNodes[14].AddNeighbour(13);
    this->sharkNodes[14].AddNeighbour(11);
    
    this->sharkNodes[15].X = 256 << 8;
    this->sharkNodes[15].Y = 345 << 8;
    this->sharkNodes[15].AddNeighbour(13);
    
}
