// All code Copyright © 2010 Mobile Asylum
//   Level generated with EndangeredEd v1.0.1.6
//
// Level Name:          First Steps
// Level Author(s):     Dean Leeks
// Build Date/Time:     24/05/2010 18:15:30
// Map File Location:   "C:\Working\Projects\Game\Editor\EndangeredEd\bin\x86\Debug\Levels"
// Map File Name:       "Level0-FirstSteps.esl"
//

#pragma once

#include "MA_LevelDescription.h"

class MA_Level0 : public MA_LevelDescription
{
public:
    MA_Level0();
};

