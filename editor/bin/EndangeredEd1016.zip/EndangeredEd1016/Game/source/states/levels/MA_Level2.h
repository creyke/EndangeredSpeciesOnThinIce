// All code Copyright © 2010 Mobile Asylum
//   Level generated with EndangeredEd v1.0.1.0
//
// Level Name:          Untitled Level
// Level Author(s):     Ryan Avent
// Build Date/Time:     10/03/2010 02:02:24
// Map File Location:   "C:\Working\Projects\game\Editor\EndangeredEd\bin\x86\Debug\Levels"
// Map File Name:       "Level2-Unnamed.esl"
//

#pragma once

#include "MA_LevelDescription.h"

class MA_Level2 : public MA_LevelDescription
{
public:
    MA_Level2();
};

