// All code Copyright © 2010 Mobile Asylum
//   Level generated with EndangeredEd v1.0.1.2
//
// Level Name:          Dean Level 2
// Level Author(s):     Dean Leeks
// Build Date/Time:     06/04/2010 12:18:54
// Map File Location:   "C:\Working\Projects\game\Editor\EndangeredEd\bin\x86\Debug\Levels"
// Map File Name:       "Level7-DeanLevel.esl"
//

#pragma once

#include "MA_LevelDescription.h"

class MA_Level7 : public MA_LevelDescription
{
public:
    MA_Level7();
};

