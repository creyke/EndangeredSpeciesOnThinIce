// All code Copyright © 2010 Mobile Asylum
//   Level generated with EndangeredEd v1.0.1.5
//
// Level Name:          Level8-RyanLevel.esl
// Level Author(s):     Ryan Avent
// Build Date/Time:     18/04/2010 00:52:36
// Map File Location:   "C:\Working\Projects\game\Editor\EndangeredEd\bin\x86\Debug\Levels"
// Map File Name:       "Level8-RyanLevel.esl"
//

#pragma once

#include "MA_LevelDescription.h"

class MA_Level8 : public MA_LevelDescription
{
public:
    MA_Level8();
};

