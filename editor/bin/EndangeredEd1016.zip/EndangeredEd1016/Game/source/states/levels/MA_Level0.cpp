// All code Copyright © 2010 Mobile Asylum
//   Level generated with EndangeredEd v1.0.1.6
//
// Level Name:          First Steps
// Level Author(s):     Dean Leeks
// Build Date/Time:     24/05/2010 18:15:30
// Map File Location:   "C:\Working\Projects\Game\Editor\EndangeredEd\bin\x86\Debug\Levels"
// Map File Name:       "Level0-FirstSteps.esl"
//

#include "MA_LevelContainer.h"
#include "MA_Level0.h"
#include "all_gfx.h"

MA_Level0::MA_Level0() : MA_LevelDescription()
{
    // NB all coordinates are (x<<8)
    this->levelName = "First Steps";
    
    // Set the dimension of the level
    this->levelWidth = 2048<<8;
    this->levelHeight = 1024<<8;
    
    // Define the goal requirements for pickups (gold, silver, bronze)
    this->pickupRequirements[0] = 25;
    this->pickupRequirements[1] = 23;
    this->pickupRequirements[2] = 22;
    
    // Define the time allowance in seconds for gold, silver, bronze
    this->totalTimeRequirements[0] = 10;
    this->totalTimeRequirements[1] = 8;
    this->totalTimeRequirements[2] = 6;
    
    // Add some tiles (xPos, yPos, tileIndex, moving, moveVectorX, movevectorY, movespeed)
    this->CreateTileSet(389<<8, 308<<8, 5, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(106<<8, 50<<8, 8, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(522<<8, 260<<8, 5, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(606<<8, 155<<8, 5, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(739<<8, 36<<8, 8, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(957<<8, 421<<8, 5, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(940<<8, 357<<8, 0, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(936<<8, 558<<8, 7, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(850<<8, 656<<8, 0, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(764<<8, 644<<8, 0, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(1188<<8, 578<<8, 5, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(1257<<8, 350<<8, 7, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(1358<<8, 212<<8, 5, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(1496<<8, 32<<8, 5, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(1445<<8, 148<<8, 0, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(1634<<8, 35<<8, 0, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(1721<<8, 57<<8, 0, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(1901<<8, 187<<8, 0, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(1865<<8, 463<<8, 0, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(1794<<8, 72<<8, 5, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(1917<<8, 401<<8, 0, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(1661<<8, 410<<8, 6, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(1888<<8, 257<<8, 5, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(1731<<8, 344<<8, 9, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(1617<<8, 560<<8, 9, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(1918<<8, 532<<8, 9, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(1288<<8, 163<<8, 9, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(702<<8, 588<<8, 0, false, 0<<8, 0<<8, 1);
    
    // Add pickups
    this->AddCollectable(890<<8, 120<<8, 16<<8, 20<<8, (void*)fishjump_Sprite, OBJ_SIZE_32X32);
    this->AddCollectable(946<<8, 142<<8, 16<<8, 20<<8, (void*)fishjump_Sprite, OBJ_SIZE_32X32);
    this->AddCollectable(970<<8, 195<<8, 16<<8, 20<<8, (void*)fishjump_Sprite, OBJ_SIZE_32X32);
    this->AddCollectable(949<<8, 250<<8, 16<<8, 20<<8, (void*)fishjump_Sprite, OBJ_SIZE_32X32);
    this->AddCollectable(891<<8, 274<<8, 16<<8, 20<<8, (void*)fishjump_Sprite, OBJ_SIZE_32X32);
    this->AddCollectable(831<<8, 246<<8, 16<<8, 20<<8, (void*)fishjump_Sprite, OBJ_SIZE_32X32);
    this->AddCollectable(810<<8, 195<<8, 16<<8, 20<<8, (void*)fishjump_Sprite, OBJ_SIZE_32X32);
    this->AddCollectable(839<<8, 145<<8, 16<<8, 20<<8, (void*)fishjump_Sprite, OBJ_SIZE_32X32);
    this->AddCollectable(975<<8, 391<<8, 16<<8, 20<<8, (void*)fishjump_Sprite, OBJ_SIZE_32X32);
    this->AddCollectable(880<<8, 688<<8, 16<<8, 20<<8, (void*)fishjump_Sprite, OBJ_SIZE_32X32);
    this->AddCollectable(794<<8, 679<<8, 16<<8, 20<<8, (void*)fishjump_Sprite, OBJ_SIZE_32X32);
    this->AddCollectable(1251<<8, 643<<8, 16<<8, 20<<8, (void*)fishjump_Sprite, OBJ_SIZE_32X32);
    this->AddCollectable(1477<<8, 182<<8, 16<<8, 20<<8, (void*)fishjump_Sprite, OBJ_SIZE_32X32);
    this->AddCollectable(1666<<8, 70<<8, 16<<8, 20<<8, (void*)fishjump_Sprite, OBJ_SIZE_32X32);
    this->AddCollectable(1900<<8, 496<<8, 16<<8, 20<<8, (void*)fishjump_Sprite, OBJ_SIZE_32X32);
    this->AddCollectable(1736<<8, 479<<8, 16<<8, 20<<8, (void*)fishjump_Sprite, OBJ_SIZE_32X32);
    this->AddCollectable(1757<<8, 457<<8, 16<<8, 20<<8, (void*)fishjump_Sprite, OBJ_SIZE_32X32);
    this->AddCollectable(1781<<8, 478<<8, 16<<8, 20<<8, (void*)fishjump_Sprite, OBJ_SIZE_32X32);
    this->AddCollectable(1797<<8, 504<<8, 16<<8, 20<<8, (void*)fishjump_Sprite, OBJ_SIZE_32X32);
    this->AddCollectable(1785<<8, 527<<8, 16<<8, 20<<8, (void*)fishjump_Sprite, OBJ_SIZE_32X32);
    this->AddCollectable(1761<<8, 545<<8, 16<<8, 20<<8, (void*)fishjump_Sprite, OBJ_SIZE_32X32);
    this->AddCollectable(1736<<8, 525<<8, 16<<8, 20<<8, (void*)fishjump_Sprite, OBJ_SIZE_32X32);
    this->AddCollectable(1718<<8, 503<<8, 16<<8, 20<<8, (void*)fishjump_Sprite, OBJ_SIZE_32X32);
    this->AddCollectable(1760<<8, 505<<8, 16<<8, 20<<8, (void*)fishjump_Sprite, OBJ_SIZE_32X32);
    this->AddCollectable(734<<8, 622<<8, 16<<8, 20<<8, (void*)fishjump_Sprite, OBJ_SIZE_32X32);
    
    // Add signs
    this->AddSign(256<<8, 175<<8, 35<<8, 52<<8, (void*)sign_3_Sprite, OBJ_SIZE_64X64, "Use the D-Pad to move the penguin around the iceberg");
    this->AddSign(252<<8, 274<<8, 35<<8, 52<<8, (void*)sign_3_Sprite, OBJ_SIZE_64X64, "Drag the stylus across the bottom screen to jump from iceberg to iceberg");
    this->AddSign(366<<8, 299<<8, 30<<8, 50<<8, (void*)sign_3_Sprite, OBJ_SIZE_64X64, "WARNING! Enter the globally warmed arctic waters for too long and you'll lose health!");
    this->AddSign(802<<8, 115<<8, 30<<8, 50<<8, (void*)sign_3_Sprite, OBJ_SIZE_64X64, "You seem to be getting the hang of this jumping lark, have a go at collecting some fish");
    this->AddSign(1021<<8, 482<<8, 30<<8, 50<<8, (void*)sign_3_Sprite, OBJ_SIZE_64X64, "The more fish collected the bigger the prizes!");
    this->AddSign(1127<<8, 643<<8, 35<<8, 52<<8, (void*)sign_3_Sprite, OBJ_SIZE_64X64, "Snowmen are checkpoints, press x next to them to save a checkpoint");
    this->AddSign(1381<<8, 471<<8, 30<<8, 50<<8, (void*)sign_3_Sprite, OBJ_SIZE_64X64, "Press the A button to scroll the camara around the enviroment. Press A again to snap it back to the character.");
    this->AddSign(1959<<8, 322<<8, 35<<8, 52<<8, (void*)sign_3_Sprite, OBJ_SIZE_64X64, "Lose all you lives and it's game over!");
    this->AddSign(1559<<8, 99<<8, 30<<8, 50<<8, (void*)sign_3_Sprite, OBJ_SIZE_64X64, "Watch out for Arctic Sharks!");
    this->AddSign(588<<8, 326<<8, 35<<8, 52<<8, (void*)sign_3_Sprite, OBJ_SIZE_64X64, "You can press the D-Pad mid jump to control your slide");
    
    // Add checkpoints
    this->AddCheckpoint(1057<<8, 681<<8, 30<<8, 50<<8, (void*)snowman_Sprite, OBJ_SIZE_64X64);
    this->AddCheckpoint(1858<<8, 137<<8, 30<<8, 50<<8, (void*)snowman_Sprite, OBJ_SIZE_64X64);
    
    // Add penguin
    this->AddPenguin(178<<8, 135<<8);
    
    // Add polar bear(s)
    
    // Add ice blocks
    
    // Add start gate
    this->AddStartGate(178<<8, 119<<8);
    
    // Add finish gate
    
    // Create shark nodes - make sure to give the nodes neighbours otherwise the shark will get stuck
    this->sharkNodeCount = 58;
    
    // Create an array of nodes
    this->sharkNodes = new MA_Node[this->sharkNodeCount];
    
    this->sharkNodes[0].X = 1629 << 8;
    this->sharkNodes[0].Y = 146 << 8;
    this->sharkNodes[0].AddNeighbour(1);
    this->sharkNodes[0].AddNeighbour(25);
    
    this->sharkNodes[1].X = 1661 << 8;
    this->sharkNodes[1].Y = 138 << 8;
    this->sharkNodes[1].AddNeighbour(0);
    this->sharkNodes[1].AddNeighbour(2);
    
    this->sharkNodes[2].X = 1695 << 8;
    this->sharkNodes[2].Y = 138 << 8;
    this->sharkNodes[2].AddNeighbour(1);
    this->sharkNodes[2].AddNeighbour(3);
    
    this->sharkNodes[3].X = 1728 << 8;
    this->sharkNodes[3].Y = 149 << 8;
    this->sharkNodes[3].AddNeighbour(2);
    this->sharkNodes[3].AddNeighbour(4);
    
    this->sharkNodes[4].X = 1758 << 8;
    this->sharkNodes[4].Y = 171 << 8;
    this->sharkNodes[4].AddNeighbour(3);
    this->sharkNodes[4].AddNeighbour(5);
    
    this->sharkNodes[5].X = 1789 << 8;
    this->sharkNodes[5].Y = 198 << 8;
    this->sharkNodes[5].AddNeighbour(4);
    this->sharkNodes[5].AddNeighbour(6);
    
    this->sharkNodes[6].X = 1819 << 8;
    this->sharkNodes[6].Y = 228 << 8;
    this->sharkNodes[6].AddNeighbour(5);
    this->sharkNodes[6].AddNeighbour(7);
    
    this->sharkNodes[7].X = 1843 << 8;
    this->sharkNodes[7].Y = 257 << 8;
    this->sharkNodes[7].AddNeighbour(6);
    this->sharkNodes[7].AddNeighbour(8);
    
    this->sharkNodes[8].X = 1856 << 8;
    this->sharkNodes[8].Y = 291 << 8;
    this->sharkNodes[8].AddNeighbour(7);
    this->sharkNodes[8].AddNeighbour(9);
    
    this->sharkNodes[9].X = 1859 << 8;
    this->sharkNodes[9].Y = 331 << 8;
    this->sharkNodes[9].AddNeighbour(8);
    this->sharkNodes[9].AddNeighbour(10);
    
    this->sharkNodes[10].X = 1867 << 8;
    this->sharkNodes[10].Y = 363 << 8;
    this->sharkNodes[10].AddNeighbour(9);
    this->sharkNodes[10].AddNeighbour(11);
    
    this->sharkNodes[11].X = 1884 << 8;
    this->sharkNodes[11].Y = 389 << 8;
    this->sharkNodes[11].AddNeighbour(10);
    this->sharkNodes[11].AddNeighbour(12);
    
    this->sharkNodes[12].X = 1886 << 8;
    this->sharkNodes[12].Y = 422 << 8;
    this->sharkNodes[12].AddNeighbour(11);
    this->sharkNodes[12].AddNeighbour(13);
    
    this->sharkNodes[13].X = 1867 << 8;
    this->sharkNodes[13].Y = 444 << 8;
    this->sharkNodes[13].AddNeighbour(12);
    this->sharkNodes[13].AddNeighbour(14);
    
    this->sharkNodes[14].X = 1842 << 8;
    this->sharkNodes[14].Y = 429 << 8;
    this->sharkNodes[14].AddNeighbour(13);
    this->sharkNodes[14].AddNeighbour(15);
    
    this->sharkNodes[15].X = 1829 << 8;
    this->sharkNodes[15].Y = 399 << 8;
    this->sharkNodes[15].AddNeighbour(14);
    this->sharkNodes[15].AddNeighbour(16);
    
    this->sharkNodes[16].X = 1822 << 8;
    this->sharkNodes[16].Y = 366 << 8;
    this->sharkNodes[16].AddNeighbour(15);
    this->sharkNodes[16].AddNeighbour(17);
    
    this->sharkNodes[17].X = 1808 << 8;
    this->sharkNodes[17].Y = 337 << 8;
    this->sharkNodes[17].AddNeighbour(16);
    this->sharkNodes[17].AddNeighbour(18);
    
    this->sharkNodes[18].X = 1777 << 8;
    this->sharkNodes[18].Y = 325 << 8;
    this->sharkNodes[18].AddNeighbour(17);
    this->sharkNodes[18].AddNeighbour(19);
    
    this->sharkNodes[19].X = 1742 << 8;
    this->sharkNodes[19].Y = 323 << 8;
    this->sharkNodes[19].AddNeighbour(18);
    this->sharkNodes[19].AddNeighbour(20);
    
    this->sharkNodes[20].X = 1710 << 8;
    this->sharkNodes[20].Y = 312 << 8;
    this->sharkNodes[20].AddNeighbour(19);
    this->sharkNodes[20].AddNeighbour(21);
    
    this->sharkNodes[21].X = 1683 << 8;
    this->sharkNodes[21].Y = 290 << 8;
    this->sharkNodes[21].AddNeighbour(20);
    this->sharkNodes[21].AddNeighbour(22);
    
    this->sharkNodes[22].X = 1656 << 8;
    this->sharkNodes[22].Y = 264 << 8;
    this->sharkNodes[22].AddNeighbour(21);
    this->sharkNodes[22].AddNeighbour(23);
    
    this->sharkNodes[23].X = 1633 << 8;
    this->sharkNodes[23].Y = 228 << 8;
    this->sharkNodes[23].AddNeighbour(22);
    this->sharkNodes[23].AddNeighbour(24);
    
    this->sharkNodes[24].X = 1618 << 8;
    this->sharkNodes[24].Y = 196 << 8;
    this->sharkNodes[24].AddNeighbour(23);
    this->sharkNodes[24].AddNeighbour(25);
    
    this->sharkNodes[25].X = 1614 << 8;
    this->sharkNodes[25].Y = 168 << 8;
    this->sharkNodes[25].AddNeighbour(24);
    this->sharkNodes[25].AddNeighbour(0);
    this->AddShark(25);
    
    this->sharkNodes[26].X = 1822 << 8;
    this->sharkNodes[26].Y = 601 << 8;
    this->sharkNodes[26].AddNeighbour(27);
    this->sharkNodes[26].AddNeighbour(37);
    
    this->sharkNodes[27].X = 1846 << 8;
    this->sharkNodes[27].Y = 583 << 8;
    this->sharkNodes[27].AddNeighbour(28);
    this->sharkNodes[27].AddNeighbour(26);
    
    this->sharkNodes[28].X = 1856 << 8;
    this->sharkNodes[28].Y = 555 << 8;
    this->sharkNodes[28].AddNeighbour(29);
    this->sharkNodes[28].AddNeighbour(27);
    
    this->sharkNodes[29].X = 1880 << 8;
    this->sharkNodes[29].Y = 547 << 8;
    this->sharkNodes[29].AddNeighbour(28);
    this->sharkNodes[29].AddNeighbour(30);
    this->AddShark(29);
    
    this->sharkNodes[30].X = 1895 << 8;
    this->sharkNodes[30].Y = 577 << 8;
    this->sharkNodes[30].AddNeighbour(31);
    this->sharkNodes[30].AddNeighbour(29);
    
    this->sharkNodes[31].X = 1883 << 8;
    this->sharkNodes[31].Y = 608 << 8;
    this->sharkNodes[31].AddNeighbour(32);
    this->sharkNodes[31].AddNeighbour(30);
    
    this->sharkNodes[32].X = 1858 << 8;
    this->sharkNodes[32].Y = 632 << 8;
    this->sharkNodes[32].AddNeighbour(33);
    this->sharkNodes[32].AddNeighbour(31);
    
    this->sharkNodes[33].X = 1832 << 8;
    this->sharkNodes[33].Y = 645 << 8;
    this->sharkNodes[33].AddNeighbour(34);
    this->sharkNodes[33].AddNeighbour(32);
    
    this->sharkNodes[34].X = 1800 << 8;
    this->sharkNodes[34].Y = 653 << 8;
    this->sharkNodes[34].AddNeighbour(36);
    this->sharkNodes[34].AddNeighbour(33);
    
    this->sharkNodes[35].X = 1690 << 8;
    this->sharkNodes[35].Y = 633 << 8;
    this->sharkNodes[35].AddNeighbour(40);
    this->sharkNodes[35].AddNeighbour(41);
    
    this->sharkNodes[36].X = 1767 << 8;
    this->sharkNodes[36].Y = 657 << 8;
    this->sharkNodes[36].AddNeighbour(42);
    this->sharkNodes[36].AddNeighbour(34);
    
    this->sharkNodes[37].X = 1794 << 8;
    this->sharkNodes[37].Y = 608 << 8;
    this->sharkNodes[37].AddNeighbour(26);
    this->sharkNodes[37].AddNeighbour(38);
    
    this->sharkNodes[38].X = 1761 << 8;
    this->sharkNodes[38].Y = 608 << 8;
    this->sharkNodes[38].AddNeighbour(37);
    this->sharkNodes[38].AddNeighbour(39);
    
    this->sharkNodes[39].X = 1729 << 8;
    this->sharkNodes[39].Y = 606 << 8;
    this->sharkNodes[39].AddNeighbour(38);
    this->sharkNodes[39].AddNeighbour(40);
    
    this->sharkNodes[40].X = 1698 << 8;
    this->sharkNodes[40].Y = 610 << 8;
    this->sharkNodes[40].AddNeighbour(39);
    this->sharkNodes[40].AddNeighbour(35);
    
    this->sharkNodes[41].X = 1710 << 8;
    this->sharkNodes[41].Y = 649 << 8;
    this->sharkNodes[41].AddNeighbour(35);
    this->sharkNodes[41].AddNeighbour(42);
    
    this->sharkNodes[42].X = 1738 << 8;
    this->sharkNodes[42].Y = 657 << 8;
    this->sharkNodes[42].AddNeighbour(41);
    this->sharkNodes[42].AddNeighbour(36);
    
    this->sharkNodes[43].X = 1655 << 8;
    this->sharkNodes[43].Y = 484 << 8;
    this->sharkNodes[43].AddNeighbour(57);
    this->sharkNodes[43].AddNeighbour(44);
    
    this->sharkNodes[44].X = 1655 << 8;
    this->sharkNodes[44].Y = 451 << 8;
    this->sharkNodes[44].AddNeighbour(45);
    this->sharkNodes[44].AddNeighbour(43);
    
    this->sharkNodes[45].X = 1670 << 8;
    this->sharkNodes[45].Y = 424 << 8;
    this->sharkNodes[45].AddNeighbour(44);
    this->sharkNodes[45].AddNeighbour(46);
    this->AddShark(45);
    
    this->sharkNodes[46].X = 1692 << 8;
    this->sharkNodes[46].Y = 406 << 8;
    this->sharkNodes[46].AddNeighbour(45);
    this->sharkNodes[46].AddNeighbour(47);
    
    this->sharkNodes[47].X = 1707 << 8;
    this->sharkNodes[47].Y = 385 << 8;
    this->sharkNodes[47].AddNeighbour(46);
    this->sharkNodes[47].AddNeighbour(48);
    
    this->sharkNodes[48].X = 1703 << 8;
    this->sharkNodes[48].Y = 358 << 8;
    this->sharkNodes[48].AddNeighbour(47);
    this->sharkNodes[48].AddNeighbour(49);
    
    this->sharkNodes[49].X = 1675 << 8;
    this->sharkNodes[49].Y = 356 << 8;
    this->sharkNodes[49].AddNeighbour(48);
    this->sharkNodes[49].AddNeighbour(50);
    
    this->sharkNodes[50].X = 1649 << 8;
    this->sharkNodes[50].Y = 375 << 8;
    this->sharkNodes[50].AddNeighbour(49);
    this->sharkNodes[50].AddNeighbour(51);
    
    this->sharkNodes[51].X = 1634 << 8;
    this->sharkNodes[51].Y = 403 << 8;
    this->sharkNodes[51].AddNeighbour(50);
    this->sharkNodes[51].AddNeighbour(52);
    
    this->sharkNodes[52].X = 1625 << 8;
    this->sharkNodes[52].Y = 437 << 8;
    this->sharkNodes[52].AddNeighbour(51);
    this->sharkNodes[52].AddNeighbour(53);
    
    this->sharkNodes[53].X = 1622 << 8;
    this->sharkNodes[53].Y = 469 << 8;
    this->sharkNodes[53].AddNeighbour(52);
    this->sharkNodes[53].AddNeighbour(54);
    
    this->sharkNodes[54].X = 1625 << 8;
    this->sharkNodes[54].Y = 501 << 8;
    this->sharkNodes[54].AddNeighbour(53);
    this->sharkNodes[54].AddNeighbour(55);
    
    this->sharkNodes[55].X = 1632 << 8;
    this->sharkNodes[55].Y = 524 << 8;
    this->sharkNodes[55].AddNeighbour(54);
    this->sharkNodes[55].AddNeighbour(56);
    
    this->sharkNodes[56].X = 1654 << 8;
    this->sharkNodes[56].Y = 537 << 8;
    this->sharkNodes[56].AddNeighbour(55);
    this->sharkNodes[56].AddNeighbour(57);
    
    this->sharkNodes[57].X = 1661 << 8;
    this->sharkNodes[57].Y = 513 << 8;
    this->sharkNodes[57].AddNeighbour(56);
    this->sharkNodes[57].AddNeighbour(43);
    
}
