// All code Copyright © 2010 Mobile Asylum
//   Level generated with EndangeredEd v1.0.1.0
//
// Level Name:          Snow Joke
// Level Author(s):     Roger Creyke
// Build Date/Time:     09/03/2010 23:11:49
// Map File Location:   "C:\Working\Projects\Game\Editor\EndangeredEd\bin\x86\Debug\Levels"
// Map File Name:       "Level4-SnowJoke.esl"
//

#pragma once

#include "MA_LevelDescription.h"

class MA_Level4 : public MA_LevelDescription
{
public:
    MA_Level4();
};

