// All code Copyright © 2010 Mobile Asylum
//   Level generated with EndangeredEd v1.0.1.2
//
// Level Name:          Testing Level
// Level Author(s):     gsd
// Build Date/Time:     12/04/2010 14:11:25
// Map File Location:   "C:\Working\Projects\game\Editor\EndangeredEd\bin\x86\Debug\Levels"
// Map File Name:       "test_level.esl"
//

#include "MA_LevelContainer.h"
#include "test_level.h"
#include "all_gfx.h"

test_level::test_level() : MA_LevelDescription()
{
    // NB all coordinates are (x<<8)
    this->levelName = "Testing Level";
    
    // Set the dimension of the level
    this->levelWidth = 1024<<8;
    this->levelHeight = 1024<<8;
    
    // Define the goal requirements for pickups (gold, silver, bronze)
    this->pickupRequirements[0] = 0;
    this->pickupRequirements[1] = 0;
    this->pickupRequirements[2] = 0;
    
    // Define the time allowance in seconds for gold, silver, bronze
    this->totalTimeRequirements[0] = 0;
    this->totalTimeRequirements[1] = 0;
    this->totalTimeRequirements[2] = 0;
    
    // Add some tiles (xPos, yPos, tileIndex, moving, moveVectorX, movevectorY, movespeed)
    this->CreateTileSet(12<<8, 9<<8, 8, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(289<<8, 89<<8, 8, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(24<<8, 297<<8, 8, false, 0<<8, 0<<8, 1);

	for (int i = 0; i < 3; i++)
	{
		this->AddIceBlock(156<<8, (156<<8) + (48<<8) * i);
	}
    
    // Add pickups
    
    // Add signs
    
    // Add checkpoints
    
    // Add penguin
	this->AddPolarBear(122<<8, 60<<8);
	this->AddPenguin(160<<8, 60<<8);



    // Create shark nodes - make sure to give the nodes neighbours otherwise the shark will get stuck
    this->sharkNodeCount = 0;
    
    // Create an array of nodes
    this->sharkNodes = new MA_Node[this->sharkNodeCount];
    
}
