// All code Copyright © 2010 Mobile Asylum
//   Level generated with EndangeredEd v1.0.1.2
//
// Level Name:          Dean Level 2
// Level Author(s):     Dean Leeks
// Build Date/Time:     06/04/2010 12:18:54
// Map File Location:   "C:\Working\Projects\game\Editor\EndangeredEd\bin\x86\Debug\Levels"
// Map File Name:       "Level7-DeanLevel.esl"
//

#include "MA_LevelContainer.h"
#include "MA_Level7.h"
#include "all_gfx.h"

MA_Level7::MA_Level7() : MA_LevelDescription()
{
    // NB all coordinates are (x<<8)
    this->levelName = "Dean Level 2";
    
    // Set the dimension of the level
    this->levelWidth = 2048<<8;
    this->levelHeight = 2048<<8;
    
    // Define the goal requirements for pickups (gold, silver, bronze)
    this->pickupRequirements[0] = 36;
    this->pickupRequirements[1] = 20;
    this->pickupRequirements[2] = 10;
    
    // Define the time allowance in seconds for gold, silver, bronze
    this->totalTimeRequirements[0] = 0;
    this->totalTimeRequirements[1] = 0;
    this->totalTimeRequirements[2] = 0;
    
    // Add some tiles (xPos, yPos, tileIndex, moving, moveVectorX, movevectorY, movespeed)
    this->CreateTileSet(883<<8, 718<<8, 8, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(517<<8, 342<<8, 7, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(1487<<8, 865<<8, 5, false, 0<<8, 0<<8, 1);
    this->AddTile(992<<8, 581<<8, 0, false, 0<<8, 0<<8, 1);
    this->AddTile(801<<8, 916<<8, 0, false, 0<<8, 0<<8, 1);
    this->AddTile(1230<<8, 857<<8, 0, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(462<<8, 752<<8, 5, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(1349<<8, 362<<8, 7, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(1038<<8, 327<<8, 5, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(776<<8, 662<<8, 9, false, 0<<8, 0<<8, 1);
    this->AddTile(690<<8, 902<<8, 0, false, 0<<8, 0<<8, 1);
    this->AddTile(616<<8, 823<<8, 0, false, 0<<8, 0<<8, 1);
    this->AddTile(1323<<8, 808<<8, 0, false, 0<<8, 0<<8, 1);
    this->AddTile(1397<<8, 872<<8, 0, false, 0<<8, 0<<8, 1);
    this->AddTile(1023<<8, 660<<8, 0, false, 0<<8, 0<<8, 1);
    this->AddTile(1006<<8, 478<<8, 0, false, 0<<8, 0<<8, 1);
    this->AddTile(991<<8, 1067<<8, 0, false, 0<<8, 0<<8, 1);
    this->AddTile(1017<<8, 1178<<8, 0, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(936<<8, 1261<<8, 5, false, 0<<8, 0<<8, 1);
    this->AddTile(1220<<8, 390<<8, 0, false, 0<<8, 0<<8, 1);
    this->AddTile(1517<<8, 765<<8, 0, false, 0<<8, 0<<8, 1);
    this->AddTile(1504<<8, 651<<8, 0, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(1300<<8, 1178<<8, 7, false, 0<<8, 0<<8, 1);
    this->AddTile(1089<<8, 1327<<8, 0, false, 0<<8, 0<<8, 1);
    this->AddTile(1197<<8, 1302<<8, 0, false, 0<<8, 0<<8, 1);
    this->AddTile(1479<<8, 1009<<8, 0, false, 0<<8, 0<<8, 1);
    this->AddTile(1511<<8, 1101<<8, 0, false, 0<<8, 0<<8, 1);
    this->AddTile(810<<8, 417<<8, 0, false, 0<<8, 0<<8, 1);
    this->AddTile(939<<8, 386<<8, 0, false, 0<<8, 0<<8, 1);
    this->AddTile(542<<8, 686<<8, 0, false, 0<<8, 0<<8, 1);
    this->AddTile(511<<8, 603<<8, 0, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(464<<8, 1128<<8, 7, false, 0<<8, 0<<8, 1);
    this->AddTile(849<<8, 1308<<8, 0, false, 0<<8, 0<<8, 1);
    this->AddTile(801<<8, 1237<<8, 0, false, 0<<8, 0<<8, 1);
    this->AddTile(732<<8, 1298<<8, 0, false, 0<<8, 0<<8, 1);
    this->AddTile(514<<8, 1030<<8, 0, false, 0<<8, 0<<8, 1);
    this->AddTile(510<<8, 924<<8, 0, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(1259<<8, 647<<8, 9, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(772<<8, 1089<<8, 9, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(1242<<8, 1054<<8, 9, false, 0<<8, 0<<8, 1);
    
    // Add pickups
    this->AddCollectable(649<<8, 531<<8, 16<<8, 20<<8, (void*)fishjump_Sprite, OBJ_SIZE_32X32);
    this->AddCollectable(686<<8, 500<<8, 16<<8, 20<<8, (void*)fishjump_Sprite, OBJ_SIZE_32X32);
    this->AddCollectable(1554<<8, 933<<8, 16<<8, 20<<8, (void*)fishjump_Sprite, OBJ_SIZE_32X32);
    this->AddCollectable(527<<8, 818<<8, 16<<8, 20<<8, (void*)fishjump_Sprite, OBJ_SIZE_32X32);
    this->AddCollectable(1102<<8, 394<<8, 16<<8, 20<<8, (void*)fishjump_Sprite, OBJ_SIZE_32X32);
    this->AddCollectable(1001<<8, 1328<<8, 16<<8, 20<<8, (void*)fishjump_Sprite, OBJ_SIZE_32X32);
    this->AddCollectable(1419<<8, 496<<8, 16<<8, 20<<8, (void*)fishjump_Sprite, OBJ_SIZE_32X32);
    this->AddCollectable(1442<<8, 538<<8, 16<<8, 20<<8, (void*)fishjump_Sprite, OBJ_SIZE_32X32);
    this->AddCollectable(1490<<8, 554<<8, 16<<8, 20<<8, (void*)fishjump_Sprite, OBJ_SIZE_32X32);
    this->AddCollectable(1531<<8, 522<<8, 16<<8, 20<<8, (void*)fishjump_Sprite, OBJ_SIZE_32X32);
    this->AddCollectable(1543<<8, 483<<8, 16<<8, 20<<8, (void*)fishjump_Sprite, OBJ_SIZE_32X32);
    this->AddCollectable(1520<<8, 443<<8, 16<<8, 20<<8, (void*)fishjump_Sprite, OBJ_SIZE_32X32);
    this->AddCollectable(1472<<8, 423<<8, 16<<8, 20<<8, (void*)fishjump_Sprite, OBJ_SIZE_32X32);
    this->AddCollectable(1428<<8, 449<<8, 16<<8, 20<<8, (void*)fishjump_Sprite, OBJ_SIZE_32X32);
    this->AddCollectable(1432<<8, 1362<<8, 16<<8, 20<<8, (void*)fishjump_Sprite, OBJ_SIZE_32X32);
    this->AddCollectable(1386<<8, 1342<<8, 16<<8, 20<<8, (void*)fishjump_Sprite, OBJ_SIZE_32X32);
    this->AddCollectable(1361<<8, 1309<<8, 16<<8, 20<<8, (void*)fishjump_Sprite, OBJ_SIZE_32X32);
    this->AddCollectable(1381<<8, 1274<<8, 16<<8, 20<<8, (void*)fishjump_Sprite, OBJ_SIZE_32X32);
    this->AddCollectable(1416<<8, 1246<<8, 16<<8, 20<<8, (void*)fishjump_Sprite, OBJ_SIZE_32X32);
    this->AddCollectable(1458<<8, 1263<<8, 16<<8, 20<<8, (void*)fishjump_Sprite, OBJ_SIZE_32X32);
    this->AddCollectable(1481<<8, 1297<<8, 16<<8, 20<<8, (void*)fishjump_Sprite, OBJ_SIZE_32X32);
    this->AddCollectable(1469<<8, 1333<<8, 16<<8, 20<<8, (void*)fishjump_Sprite, OBJ_SIZE_32X32);
    this->AddCollectable(696<<8, 459<<8, 16<<8, 20<<8, (void*)fishjump_Sprite, OBJ_SIZE_32X32);
    this->AddCollectable(677<<8, 427<<8, 16<<8, 20<<8, (void*)fishjump_Sprite, OBJ_SIZE_32X32);
    this->AddCollectable(633<<8, 409<<8, 16<<8, 20<<8, (void*)fishjump_Sprite, OBJ_SIZE_32X32);
    this->AddCollectable(581<<8, 467<<8, 16<<8, 20<<8, (void*)fishjump_Sprite, OBJ_SIZE_32X32);
    this->AddCollectable(602<<8, 509<<8, 16<<8, 20<<8, (void*)fishjump_Sprite, OBJ_SIZE_32X32);
    this->AddCollectable(599<<8, 434<<8, 16<<8, 20<<8, (void*)fishjump_Sprite, OBJ_SIZE_32X32);
    this->AddCollectable(593<<8, 1314<<8, 16<<8, 20<<8, (void*)fishjump_Sprite, OBJ_SIZE_32X32);
    this->AddCollectable(632<<8, 1292<<8, 16<<8, 20<<8, (void*)fishjump_Sprite, OBJ_SIZE_32X32);
    this->AddCollectable(653<<8, 1254<<8, 16<<8, 20<<8, (void*)fishjump_Sprite, OBJ_SIZE_32X32);
    this->AddCollectable(630<<8, 1218<<8, 16<<8, 20<<8, (void*)fishjump_Sprite, OBJ_SIZE_32X32);
    this->AddCollectable(589<<8, 1200<<8, 16<<8, 20<<8, (void*)fishjump_Sprite, OBJ_SIZE_32X32);
    this->AddCollectable(556<<8, 1218<<8, 16<<8, 20<<8, (void*)fishjump_Sprite, OBJ_SIZE_32X32);
    this->AddCollectable(536<<8, 1251<<8, 16<<8, 20<<8, (void*)fishjump_Sprite, OBJ_SIZE_32X32);
    this->AddCollectable(549<<8, 1285<<8, 16<<8, 20<<8, (void*)fishjump_Sprite, OBJ_SIZE_32X32);
    
    // Add signs
    this->AddSign(1124<<8, 856<<8, 35<<8, 52<<8, (void*)sign_3_Sprite, OBJ_SIZE_64X64, "Careful! Many sharks patrol this area.");
    this->AddSign(987<<8, 804<<8, 30<<8, 50<<8, (void*)sign_3_Sprite, OBJ_SIZE_64X64, "36 fish are scattered around here. Can you find them all?");
    this->AddSign(973<<8, 912<<8, 35<<8, 52<<8, (void*)sign_3_Sprite, OBJ_SIZE_64X64, "Hint, head for the corners ;)");
    
    // Add checkpoints
    this->AddCheckpoint(1067<<8, 839<<8, 30<<8, 50<<8, (void*)snowman_Sprite, OBJ_SIZE_64X64);
    
    // Add penguin
    this->AddPenguin(1041<<8, 880<<8);
    
    // Create shark nodes - make sure to give the nodes neighbours otherwise the shark will get stuck
    this->sharkNodeCount = 93;
    
    // Create an array of nodes
    this->sharkNodes = new MA_Node[this->sharkNodeCount];
    
    this->sharkNodes[0].X = 1197 << 8;
    this->sharkNodes[0].Y = 897 << 8;
    this->sharkNodes[0].AddNeighbour(1);
    this->sharkNodes[0].AddNeighbour(7);
    this->AddShark(0);
    
    this->sharkNodes[1].X = 1209 << 8;
    this->sharkNodes[1].Y = 860 << 8;
    this->sharkNodes[1].AddNeighbour(0);
    this->sharkNodes[1].AddNeighbour(2);
    
    this->sharkNodes[2].X = 1247 << 8;
    this->sharkNodes[2].Y = 830 << 8;
    this->sharkNodes[2].AddNeighbour(1);
    this->sharkNodes[2].AddNeighbour(3);
    
    this->sharkNodes[3].X = 1293 << 8;
    this->sharkNodes[3].Y = 842 << 8;
    this->sharkNodes[3].AddNeighbour(2);
    this->sharkNodes[3].AddNeighbour(4);
    
    this->sharkNodes[4].X = 1321 << 8;
    this->sharkNodes[4].Y = 883 << 8;
    this->sharkNodes[4].AddNeighbour(3);
    this->sharkNodes[4].AddNeighbour(5);
    
    this->sharkNodes[5].X = 1311 << 8;
    this->sharkNodes[5].Y = 931 << 8;
    this->sharkNodes[5].AddNeighbour(4);
    this->sharkNodes[5].AddNeighbour(6);
    
    this->sharkNodes[6].X = 1266 << 8;
    this->sharkNodes[6].Y = 951 << 8;
    this->sharkNodes[6].AddNeighbour(5);
    this->sharkNodes[6].AddNeighbour(7);
    
    this->sharkNodes[7].X = 1221 << 8;
    this->sharkNodes[7].Y = 940 << 8;
    this->sharkNodes[7].AddNeighbour(6);
    this->sharkNodes[7].AddNeighbour(0);
    
    this->sharkNodes[8].X = 778 << 8;
    this->sharkNodes[8].Y = 953 << 8;
    this->sharkNodes[8].AddNeighbour(14);
    this->sharkNodes[8].AddNeighbour(9);
    this->AddShark(8);
    
    this->sharkNodes[9].X = 774 << 8;
    this->sharkNodes[9].Y = 906 << 8;
    this->sharkNodes[9].AddNeighbour(8);
    this->sharkNodes[9].AddNeighbour(10);
    
    this->sharkNodes[10].X = 732 << 8;
    this->sharkNodes[10].Y = 879 << 8;
    this->sharkNodes[10].AddNeighbour(9);
    this->sharkNodes[10].AddNeighbour(11);
    
    this->sharkNodes[11].X = 685 << 8;
    this->sharkNodes[11].Y = 896 << 8;
    this->sharkNodes[11].AddNeighbour(10);
    this->sharkNodes[11].AddNeighbour(12);
    
    this->sharkNodes[12].X = 662 << 8;
    this->sharkNodes[12].Y = 938 << 8;
    this->sharkNodes[12].AddNeighbour(11);
    this->sharkNodes[12].AddNeighbour(13);
    
    this->sharkNodes[13].X = 689 << 8;
    this->sharkNodes[13].Y = 979 << 8;
    this->sharkNodes[13].AddNeighbour(12);
    this->sharkNodes[13].AddNeighbour(14);
    
    this->sharkNodes[14].X = 743 << 8;
    this->sharkNodes[14].Y = 989 << 8;
    this->sharkNodes[14].AddNeighbour(8);
    this->sharkNodes[14].AddNeighbour(13);
    
    this->sharkNodes[15].X = 1070 << 8;
    this->sharkNodes[15].Y = 561 << 8;
    this->sharkNodes[15].AddNeighbour(16);
    this->sharkNodes[15].AddNeighbour(18);
    
    this->sharkNodes[16].X = 1095 << 8;
    this->sharkNodes[16].Y = 522 << 8;
    this->sharkNodes[16].AddNeighbour(17);
    this->sharkNodes[16].AddNeighbour(15);
    
    this->sharkNodes[17].X = 1082 << 8;
    this->sharkNodes[17].Y = 476 << 8;
    this->sharkNodes[17].AddNeighbour(21);
    this->sharkNodes[17].AddNeighbour(16);
    
    this->sharkNodes[18].X = 1021 << 8;
    this->sharkNodes[18].Y = 565 << 8;
    this->sharkNodes[18].AddNeighbour(15);
    this->sharkNodes[18].AddNeighbour(19);
    this->AddShark(18);
    
    this->sharkNodes[19].X = 983 << 8;
    this->sharkNodes[19].Y = 528 << 8;
    this->sharkNodes[19].AddNeighbour(18);
    this->sharkNodes[19].AddNeighbour(78);
    
    this->sharkNodes[20].X = 976 << 8;
    this->sharkNodes[20].Y = 469 << 8;
    this->sharkNodes[20].AddNeighbour(21);
    this->sharkNodes[20].AddNeighbour(72);
    this->AddShark(20);
    
    this->sharkNodes[21].X = 1039 << 8;
    this->sharkNodes[21].Y = 452 << 8;
    this->sharkNodes[21].AddNeighbour(17);
    this->sharkNodes[21].AddNeighbour(20);
    
    this->sharkNodes[22].X = 1022 << 8;
    this->sharkNodes[22].Y = 1049 << 8;
    this->sharkNodes[22].AddNeighbour(35);
    this->sharkNodes[22].AddNeighbour(23);
    this->AddShark(22);
    
    this->sharkNodes[23].X = 1067 << 8;
    this->sharkNodes[23].Y = 1064 << 8;
    this->sharkNodes[23].AddNeighbour(22);
    this->sharkNodes[23].AddNeighbour(24);
    
    this->sharkNodes[24].X = 1076 << 8;
    this->sharkNodes[24].Y = 1104 << 8;
    this->sharkNodes[24].AddNeighbour(25);
    this->sharkNodes[24].AddNeighbour(23);
    
    this->sharkNodes[25].X = 1055 << 8;
    this->sharkNodes[25].Y = 1137 << 8;
    this->sharkNodes[25].AddNeighbour(24);
    this->sharkNodes[25].AddNeighbour(26);
    
    this->sharkNodes[26].X = 1014 << 8;
    this->sharkNodes[26].Y = 1167 << 8;
    this->sharkNodes[26].AddNeighbour(25);
    this->sharkNodes[26].AddNeighbour(27);
    
    this->sharkNodes[27].X = 989 << 8;
    this->sharkNodes[27].Y = 1202 << 8;
    this->sharkNodes[27].AddNeighbour(26);
    this->sharkNodes[27].AddNeighbour(28);
    
    this->sharkNodes[28].X = 1002 << 8;
    this->sharkNodes[28].Y = 1242 << 8;
    this->sharkNodes[28].AddNeighbour(27);
    this->sharkNodes[28].AddNeighbour(29);
    
    this->sharkNodes[29].X = 1043 << 8;
    this->sharkNodes[29].Y = 1267 << 8;
    this->sharkNodes[29].AddNeighbour(28);
    this->sharkNodes[29].AddNeighbour(30);
    
    this->sharkNodes[30].X = 1088 << 8;
    this->sharkNodes[30].Y = 1248 << 8;
    this->sharkNodes[30].AddNeighbour(29);
    this->sharkNodes[30].AddNeighbour(31);
    
    this->sharkNodes[31].X = 1104 << 8;
    this->sharkNodes[31].Y = 1205 << 8;
    this->sharkNodes[31].AddNeighbour(30);
    this->sharkNodes[31].AddNeighbour(32);
    
    this->sharkNodes[32].X = 1071 << 8;
    this->sharkNodes[32].Y = 1165 << 8;
    this->sharkNodes[32].AddNeighbour(31);
    this->sharkNodes[32].AddNeighbour(33);
    
    this->sharkNodes[33].X = 1006 << 8;
    this->sharkNodes[33].Y = 1146 << 8;
    this->sharkNodes[33].AddNeighbour(32);
    this->sharkNodes[33].AddNeighbour(34);
    
    this->sharkNodes[34].X = 970 << 8;
    this->sharkNodes[34].Y = 1114 << 8;
    this->sharkNodes[34].AddNeighbour(33);
    this->sharkNodes[34].AddNeighbour(35);
    
    this->sharkNodes[35].X = 980 << 8;
    this->sharkNodes[35].Y = 1067 << 8;
    this->sharkNodes[35].AddNeighbour(34);
    this->sharkNodes[35].AddNeighbour(22);
    
    this->sharkNodes[36].X = 1194 << 8;
    this->sharkNodes[36].Y = 454 << 8;
    this->sharkNodes[36].AddNeighbour(37);
    this->sharkNodes[36].AddNeighbour(43);
    
    this->sharkNodes[37].X = 1189 << 8;
    this->sharkNodes[37].Y = 412 << 8;
    this->sharkNodes[37].AddNeighbour(38);
    this->sharkNodes[37].AddNeighbour(36);
    
    this->sharkNodes[38].X = 1211 << 8;
    this->sharkNodes[38].Y = 375 << 8;
    this->sharkNodes[38].AddNeighbour(39);
    this->sharkNodes[38].AddNeighbour(37);
    
    this->sharkNodes[39].X = 1260 << 8;
    this->sharkNodes[39].Y = 367 << 8;
    this->sharkNodes[39].AddNeighbour(40);
    this->sharkNodes[39].AddNeighbour(38);
    
    this->sharkNodes[40].X = 1306 << 8;
    this->sharkNodes[40].Y = 388 << 8;
    this->sharkNodes[40].AddNeighbour(41);
    this->sharkNodes[40].AddNeighbour(39);
    
    this->sharkNodes[41].X = 1316 << 8;
    this->sharkNodes[41].Y = 430 << 8;
    this->sharkNodes[41].AddNeighbour(42);
    this->sharkNodes[41].AddNeighbour(40);
    this->AddShark(41);
    
    this->sharkNodes[42].X = 1290 << 8;
    this->sharkNodes[42].Y = 469 << 8;
    this->sharkNodes[42].AddNeighbour(43);
    this->sharkNodes[42].AddNeighbour(41);
    
    this->sharkNodes[43].X = 1241 << 8;
    this->sharkNodes[43].Y = 477 << 8;
    this->sharkNodes[43].AddNeighbour(42);
    this->sharkNodes[43].AddNeighbour(36);
    
    this->sharkNodes[44].X = 1550 << 8;
    this->sharkNodes[44].Y = 850 << 8;
    this->sharkNodes[44].AddNeighbour(45);
    this->sharkNodes[44].AddNeighbour(57);
    
    this->sharkNodes[45].X = 1502 << 8;
    this->sharkNodes[45].Y = 825 << 8;
    this->sharkNodes[45].AddNeighbour(46);
    this->sharkNodes[45].AddNeighbour(44);
    
    this->sharkNodes[46].X = 1499 << 8;
    this->sharkNodes[46].Y = 778 << 8;
    this->sharkNodes[46].AddNeighbour(47);
    this->sharkNodes[46].AddNeighbour(45);
    
    this->sharkNodes[47].X = 1536 << 8;
    this->sharkNodes[47].Y = 749 << 8;
    this->sharkNodes[47].AddNeighbour(48);
    this->sharkNodes[47].AddNeighbour(46);
    this->AddShark(47);
    
    this->sharkNodes[48].X = 1573 << 8;
    this->sharkNodes[48].Y = 725 << 8;
    this->sharkNodes[48].AddNeighbour(49);
    this->sharkNodes[48].AddNeighbour(47);
    
    this->sharkNodes[49].X = 1593 << 8;
    this->sharkNodes[49].Y = 690 << 8;
    this->sharkNodes[49].AddNeighbour(50);
    this->sharkNodes[49].AddNeighbour(48);
    
    this->sharkNodes[50].X = 1575 << 8;
    this->sharkNodes[50].Y = 646 << 8;
    this->sharkNodes[50].AddNeighbour(51);
    this->sharkNodes[50].AddNeighbour(49);
    
    this->sharkNodes[51].X = 1532 << 8;
    this->sharkNodes[51].Y = 627 << 8;
    this->sharkNodes[51].AddNeighbour(52);
    this->sharkNodes[51].AddNeighbour(50);
    
    this->sharkNodes[52].X = 1489 << 8;
    this->sharkNodes[52].Y = 646 << 8;
    this->sharkNodes[52].AddNeighbour(53);
    this->sharkNodes[52].AddNeighbour(51);
    
    this->sharkNodes[53].X = 1472 << 8;
    this->sharkNodes[53].Y = 690 << 8;
    this->sharkNodes[53].AddNeighbour(54);
    this->sharkNodes[53].AddNeighbour(52);
    
    this->sharkNodes[54].X = 1496 << 8;
    this->sharkNodes[54].Y = 726 << 8;
    this->sharkNodes[54].AddNeighbour(53);
    this->sharkNodes[54].AddNeighbour(55);
    
    this->sharkNodes[55].X = 1571 << 8;
    this->sharkNodes[55].Y = 748 << 8;
    this->sharkNodes[55].AddNeighbour(56);
    this->sharkNodes[55].AddNeighbour(54);
    
    this->sharkNodes[56].X = 1603 << 8;
    this->sharkNodes[56].Y = 780 << 8;
    this->sharkNodes[56].AddNeighbour(57);
    this->sharkNodes[56].AddNeighbour(55);
    
    this->sharkNodes[57].X = 1592 << 8;
    this->sharkNodes[57].Y = 824 << 8;
    this->sharkNodes[57].AddNeighbour(44);
    this->sharkNodes[57].AddNeighbour(56);
    
    this->sharkNodes[58].X = 1173 << 8;
    this->sharkNodes[58].Y = 1329 << 8;
    this->sharkNodes[58].AddNeighbour(59);
    this->sharkNodes[58].AddNeighbour(64);
    
    this->sharkNodes[59].X = 1196 << 8;
    this->sharkNodes[59].Y = 1291 << 8;
    this->sharkNodes[59].AddNeighbour(60);
    this->sharkNodes[59].AddNeighbour(58);
    
    this->sharkNodes[60].X = 1240 << 8;
    this->sharkNodes[60].Y = 1285 << 8;
    this->sharkNodes[60].AddNeighbour(61);
    this->sharkNodes[60].AddNeighbour(59);
    
    this->sharkNodes[61].X = 1279 << 8;
    this->sharkNodes[61].Y = 1309 << 8;
    this->sharkNodes[61].AddNeighbour(62);
    this->sharkNodes[61].AddNeighbour(60);
    this->AddShark(61);
    
    this->sharkNodes[62].X = 1280 << 8;
    this->sharkNodes[62].Y = 1352 << 8;
    this->sharkNodes[62].AddNeighbour(63);
    this->sharkNodes[62].AddNeighbour(61);
    
    this->sharkNodes[63].X = 1244 << 8;
    this->sharkNodes[63].Y = 1388 << 8;
    this->sharkNodes[63].AddNeighbour(62);
    this->sharkNodes[63].AddNeighbour(64);
    
    this->sharkNodes[64].X = 1189 << 8;
    this->sharkNodes[64].Y = 1373 << 8;
    this->sharkNodes[64].AddNeighbour(58);
    this->sharkNodes[64].AddNeighbour(63);
    
    this->sharkNodes[65].X = 1487 << 8;
    this->sharkNodes[65].Y = 1136 << 8;
    this->sharkNodes[65].AddNeighbour(71);
    this->sharkNodes[65].AddNeighbour(66);
    
    this->sharkNodes[66].X = 1508 << 8;
    this->sharkNodes[66].Y = 1171 << 8;
    this->sharkNodes[66].AddNeighbour(65);
    this->sharkNodes[66].AddNeighbour(67);
    
    this->sharkNodes[67].X = 1552 << 8;
    this->sharkNodes[67].Y = 1190 << 8;
    this->sharkNodes[67].AddNeighbour(66);
    this->sharkNodes[67].AddNeighbour(68);
    this->AddShark(67);
    
    this->sharkNodes[68].X = 1591 << 8;
    this->sharkNodes[68].Y = 1167 << 8;
    this->sharkNodes[68].AddNeighbour(67);
    this->sharkNodes[68].AddNeighbour(69);
    
    this->sharkNodes[69].X = 1595 << 8;
    this->sharkNodes[69].Y = 1116 << 8;
    this->sharkNodes[69].AddNeighbour(68);
    this->sharkNodes[69].AddNeighbour(70);
    
    this->sharkNodes[70].X = 1555 << 8;
    this->sharkNodes[70].Y = 1085 << 8;
    this->sharkNodes[70].AddNeighbour(69);
    this->sharkNodes[70].AddNeighbour(71);
    
    this->sharkNodes[71].X = 1508 << 8;
    this->sharkNodes[71].Y = 1093 << 8;
    this->sharkNodes[71].AddNeighbour(65);
    this->sharkNodes[71].AddNeighbour(70);
    
    this->sharkNodes[72].X = 927 << 8;
    this->sharkNodes[72].Y = 453 << 8;
    this->sharkNodes[72].AddNeighbour(73);
    this->sharkNodes[72].AddNeighbour(20);
    
    this->sharkNodes[73].X = 913 << 8;
    this->sharkNodes[73].Y = 409 << 8;
    this->sharkNodes[73].AddNeighbour(74);
    this->sharkNodes[73].AddNeighbour(72);
    
    this->sharkNodes[74].X = 942 << 8;
    this->sharkNodes[74].Y = 370 << 8;
    this->sharkNodes[74].AddNeighbour(75);
    this->sharkNodes[74].AddNeighbour(73);
    
    this->sharkNodes[75].X = 984 << 8;
    this->sharkNodes[75].Y = 366 << 8;
    this->sharkNodes[75].AddNeighbour(76);
    this->sharkNodes[75].AddNeighbour(74);
    
    this->sharkNodes[76].X = 1019 << 8;
    this->sharkNodes[76].Y = 392 << 8;
    this->sharkNodes[76].AddNeighbour(77);
    this->sharkNodes[76].AddNeighbour(75);
    
    this->sharkNodes[77].X = 1017 << 8;
    this->sharkNodes[77].Y = 437 << 8;
    this->sharkNodes[77].AddNeighbour(78);
    this->sharkNodes[77].AddNeighbour(76);
    
    this->sharkNodes[78].X = 986 << 8;
    this->sharkNodes[78].Y = 479 << 8;
    this->sharkNodes[78].AddNeighbour(19);
    this->sharkNodes[78].AddNeighbour(77);
    
    this->sharkNodes[79].X = 545 << 8;
    this->sharkNodes[79].Y = 1112 << 8;
    this->sharkNodes[79].AddNeighbour(92);
    this->sharkNodes[79].AddNeighbour(80);
    
    this->sharkNodes[80].X = 589 << 8;
    this->sharkNodes[80].Y = 1093 << 8;
    this->sharkNodes[80].AddNeighbour(79);
    this->sharkNodes[80].AddNeighbour(81);
    
    this->sharkNodes[81].X = 605 << 8;
    this->sharkNodes[81].Y = 1046 << 8;
    this->sharkNodes[81].AddNeighbour(82);
    this->sharkNodes[81].AddNeighbour(80);
    
    this->sharkNodes[82].X = 570 << 8;
    this->sharkNodes[82].Y = 1013 << 8;
    this->sharkNodes[82].AddNeighbour(81);
    this->sharkNodes[82].AddNeighbour(83);
    
    this->sharkNodes[83].X = 525 << 8;
    this->sharkNodes[83].Y = 1006 << 8;
    this->sharkNodes[83].AddNeighbour(82);
    this->sharkNodes[83].AddNeighbour(84);
    this->AddShark(83);
    
    this->sharkNodes[84].X = 490 << 8;
    this->sharkNodes[84].Y = 980 << 8;
    this->sharkNodes[84].AddNeighbour(83);
    this->sharkNodes[84].AddNeighbour(85);
    
    this->sharkNodes[85].X = 486 << 8;
    this->sharkNodes[85].Y = 935 << 8;
    this->sharkNodes[85].AddNeighbour(84);
    this->sharkNodes[85].AddNeighbour(86);
    
    this->sharkNodes[86].X = 518 << 8;
    this->sharkNodes[86].Y = 904 << 8;
    this->sharkNodes[86].AddNeighbour(85);
    this->sharkNodes[86].AddNeighbour(87);
    
    this->sharkNodes[87].X = 563 << 8;
    this->sharkNodes[87].Y = 903 << 8;
    this->sharkNodes[87].AddNeighbour(86);
    this->sharkNodes[87].AddNeighbour(88);
    
    this->sharkNodes[88].X = 598 << 8;
    this->sharkNodes[88].Y = 932 << 8;
    this->sharkNodes[88].AddNeighbour(87);
    this->sharkNodes[88].AddNeighbour(89);
    
    this->sharkNodes[89].X = 592 << 8;
    this->sharkNodes[89].Y = 979 << 8;
    this->sharkNodes[89].AddNeighbour(88);
    this->sharkNodes[89].AddNeighbour(90);
    
    this->sharkNodes[90].X = 503 << 8;
    this->sharkNodes[90].Y = 1026 << 8;
    this->sharkNodes[90].AddNeighbour(89);
    this->sharkNodes[90].AddNeighbour(91);
    
    this->sharkNodes[91].X = 488 << 8;
    this->sharkNodes[91].Y = 1065 << 8;
    this->sharkNodes[91].AddNeighbour(90);
    this->sharkNodes[91].AddNeighbour(92);
    
    this->sharkNodes[92].X = 505 << 8;
    this->sharkNodes[92].Y = 1098 << 8;
    this->sharkNodes[92].AddNeighbour(91);
    this->sharkNodes[92].AddNeighbour(79);
    
}
