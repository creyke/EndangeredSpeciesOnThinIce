
#pragma once

#include "MA_LevelDescription.h"
#include "MA_LevelResult.h"

class MA_LevelContainer
{
public:
	const static int maxLevels = 10;

private:

	static MA_LevelDescription* levels[maxLevels];
	static int levelCount;
	// Contains best results for all levels. if no result then level has not been completed
	static MA_LevelResult* levelResults[maxLevels];
	// The level index that was the last one completed or -1 for none
	static s8 lastCompletedLevel;

	// The last level the player attempted, regardless of the result
	static s8 lastAttemptedLevel;

	static MA_LevelResult* lastLevelResult;
public:

	static void AddLevel(MA_LevelDescription* level);

	static MA_LevelDescription* GetLevel(int index);

	static int GetLevelCount();

	// Gets the index of the specified level or -1 if the level is not in the container
	static s8 GetLevelIndex(MA_LevelDescription* level);

	// Returns the level that was last completed for the first time. If index is -1 then no level has been completed
	static s8 GetLastCompletedLevel();

	// Gets the last level the player attempted, regardless of the result
	static s8 GetLastAttemptedLevel();
	// Sets the last level the player attempted, regardless of the result
	static void SetLastAttemptedLevel(s8 levelIndex);

	// When the player has attempted a level, the result should be passed to this function so the data is recorded
	static void SetNewLevelResult(MA_LevelResult* result);

	// Gets the level result for the specified level. null returned if level not completed
	static MA_LevelResult* GetLevelResult(u8 levelIndex);
	static MA_LevelResult* GetLastLevelResult();
};