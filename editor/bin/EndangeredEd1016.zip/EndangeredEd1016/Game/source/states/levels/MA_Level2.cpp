// All code Copyright © 2010 Mobile Asylum
//   Level generated with EndangeredEd v1.0.1.0
//
// Level Name:          Untitled Level
// Level Author(s):     Ryan Avent
// Build Date/Time:     10/03/2010 02:02:24
// Map File Location:   "C:\Working\Projects\game\Editor\EndangeredEd\bin\x86\Debug\Levels"
// Map File Name:       "Level2-Unnamed.esl"
//

#include "MA_LevelContainer.h"
#include "MA_Level2.h"
#include "all_gfx.h"

MA_Level2::MA_Level2() : MA_LevelDescription()
{
    // NB all coordinates are (x<<8)
    this->levelName = "Untitled Level";
    
    // Set the dimension of the level
    this->levelWidth = 1024<<8;
    this->levelHeight = 1024<<8;
    
    // Define the goal requirements for pickups (gold, silver, bronze)
    this->pickupRequirements[0] = 0;
    this->pickupRequirements[1] = 0;
    this->pickupRequirements[2] = 0;
    
    // Define the time allowance in seconds for gold, silver, bronze
    this->totalTimeRequirements[0] = 0;
    this->totalTimeRequirements[1] = 0;
    this->totalTimeRequirements[2] = 0;
    
    // Add some tiles (xPos, yPos, tileIndex, moving, moveVectorX, movevectorY, movespeed)
    this->CreateTileSet(510<<8, 16<<8, 7, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(407<<8, 206<<8, 5, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(760<<8, 216<<8, 5, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(491<<8, 445<<8, 6, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(719<<8, 813<<8, 6, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(270<<8, 769<<8, 5, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(67<<8, 579<<8, 5, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(155<<8, 240<<8, 5, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(122<<8, 176<<8, 0, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(19<<8, 31<<8, 5, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(304<<8, 491<<8, 0, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(216<<8, 567<<8, 0, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(398<<8, 515<<8, 0, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(702<<8, 469<<8, 0, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(800<<8, 417<<8, 0, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(887<<8, 346<<8, 0, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(858<<8, 502<<8, 0, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(911<<8, 591<<8, 0, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(258<<8, 394<<8, 0, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(552<<8, 722<<8, 0, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(434<<8, 764<<8, 0, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(639<<8, 799<<8, 0, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(192<<8, 853<<8, 0, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(337<<8, 918<<8, 0, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(805<<8, 54<<8, 0, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(913<<8, 35<<8, 0, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(630<<8, 641<<8, 0, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(311<<8, 260<<8, 0, false, 0<<8, 0<<8, 1);
    
    // Add pickups
    this->AddCollectable(565<<8, 545<<8, 16<<8, 20<<8, (void*)fishjump_Sprite, OBJ_SIZE_32X32);
    this->AddCollectable(839<<8, 895<<8, 16<<8, 20<<8, (void*)fishjump_Sprite, OBJ_SIZE_32X32);
    this->AddCollectable(133<<8, 644<<8, 16<<8, 20<<8, (void*)fishjump_Sprite, OBJ_SIZE_32X32);
    this->AddCollectable(85<<8, 105<<8, 16<<8, 20<<8, (void*)fishjump_Sprite, OBJ_SIZE_32X32);
    this->AddCollectable(833<<8, 447<<8, 16<<8, 20<<8, (void*)fishjump_Sprite, OBJ_SIZE_32X32);
    this->AddCollectable(945<<8, 624<<8, 16<<8, 20<<8, (void*)fishjump_Sprite, OBJ_SIZE_32X32);
    this->AddCollectable(290<<8, 426<<8, 16<<8, 20<<8, (void*)fishjump_Sprite, OBJ_SIZE_32X32);
    this->AddCollectable(226<<8, 886<<8, 16<<8, 20<<8, (void*)fishjump_Sprite, OBJ_SIZE_32X32);
    this->AddCollectable(364<<8, 951<<8, 16<<8, 20<<8, (void*)fishjump_Sprite, OBJ_SIZE_32X32);
    this->AddCollectable(946<<8, 71<<8, 16<<8, 20<<8, (void*)fishjump_Sprite, OBJ_SIZE_32X32);
    
    // Add signs
    this->AddSign(568<<8, 219<<8, 35<<8, 53<<8, (void*)sign_3_Sprite, OBJ_SIZE_64X64, "");
    this->AddSign(710<<8, 220<<8, 28<<8, 53<<8, (void*)sign_3_Sprite, OBJ_SIZE_64X64, "");
    this->AddSign(932<<8, 375<<8, 34<<8, 53<<8, (void*)sign_3_Sprite, OBJ_SIZE_64X64, "");
    this->AddSign(340<<8, 515<<8, 28<<8, 53<<8, (void*)sign_3_Sprite, OBJ_SIZE_64X64, "");
    this->AddSign(666<<8, 669<<8, 34<<8, 53<<8, (void*)sign_3_Sprite, OBJ_SIZE_64X64, "");
    
    // Add checkpoints
    //this->AddCheckpoint(605<<8, 144<<8, 30<<8, 53<<8, (void*)snowman_Sprite, OBJ_SIZE_64X64);
    this->AddCheckpoint(590<<8, 523<<8, 30<<8, 53<<8, (void*)snowman_Sprite, OBJ_SIZE_64X64);
    this->AddCheckpoint(323<<8, 840<<8, 30<<8, 53<<8, (void*)snowman_Sprite, OBJ_SIZE_64X64);
    this->AddCheckpoint(209<<8, 316<<8, 30<<8, 53<<8, (void*)snowman_Sprite, OBJ_SIZE_64X64);
    
	// Create boat wreck entity
	this->AddEnvironmentEntity((805<<8)  + mapTileSizeOverTwo, (54<<8) + mapTileSizeOverTwo, 2);
	// Create skeleton entity
	this->AddEnvironmentEntity((651 + 30)<<8, (147+20)<<8, 3);

    // Add penguin
    this->AddPenguin(651<<8, 147<<8);
    this->AddStartGate(651<<8, 147<<8);

    // Create shark nodes - make sure to give the nodes neighbours otherwise the shark will get stuck
    this->sharkNodeCount = 0;
    
    // Create an array of nodes
    this->sharkNodes = new MA_Node[this->sharkNodeCount];
    
}
