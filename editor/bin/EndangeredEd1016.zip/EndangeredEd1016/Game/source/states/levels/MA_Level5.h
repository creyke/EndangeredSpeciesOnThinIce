// All code Copyright © 2010 Mobile Asylum
//   Level generated with EndangeredEd v1.0.1.0
//
// Level Name:          Give me a name
// Level Author(s):     George Daters
// Build Date/Time:     10/03/2010 01:07:05
// Map File Location:   "C:\Working\Projects\game\Editor\EndangeredEd\bin\x86\Debug\Levels"
// Map File Name:       "Level5-NoName.esl"
//

#pragma once

#include "MA_LevelDescription.h"

class MA_Level5 : public MA_LevelDescription
{
public:
    MA_Level5();
};

