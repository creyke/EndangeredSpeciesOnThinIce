// All code Copyright © 2010 Mobile Asylum
//   Level generated with EndangeredEd v1.0.1.2
//
// Level Name:          Tile Demo
// Level Author(s):     gsd
// Build Date/Time:     26/03/2010 15:34:42
// Map File Location:   "C:\working\projects\game\Editor\EndangeredEd\bin\x86\Debug\Levels"
// Map File Name:       "LevelTemplate.esl"
//

#pragma once

#include "MA_LevelDescription.h"

class MA_Level6 : public MA_LevelDescription
{
public:
    MA_Level6();
};

