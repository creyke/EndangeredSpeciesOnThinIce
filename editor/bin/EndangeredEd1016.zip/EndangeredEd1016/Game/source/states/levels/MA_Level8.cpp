// All code Copyright © 2010 Mobile Asylum
//   Level generated with EndangeredEd v1.0.1.5
//
// Level Name:          Level8-RyanLevel.esl
// Level Author(s):     Ryan Avent
// Build Date/Time:     18/04/2010 00:52:36
// Map File Location:   "C:\Working\Projects\game\Editor\EndangeredEd\bin\x86\Debug\Levels"
// Map File Name:       "Level8-RyanLevel.esl"
//

#include "MA_LevelContainer.h"
#include "MA_Level8.h"
#include "all_gfx.h"

MA_Level8::MA_Level8() : MA_LevelDescription()
{
    // NB all coordinates are (x<<8)
    this->levelName = "Level8-RyanLevel.esl";
    
    // Set the dimension of the level
    this->levelWidth = 1024<<8;
    this->levelHeight = 1024<<8;
    
    // Define the goal requirements for pickups (gold, silver, bronze)
    this->pickupRequirements[0] = 15;
    this->pickupRequirements[1] = 10;
    this->pickupRequirements[2] = 6;
    
    // Define the time allowance in seconds for gold, silver, bronze
    this->totalTimeRequirements[0] = 0;
    this->totalTimeRequirements[1] = 0;
    this->totalTimeRequirements[2] = 0;
    
    // Add some tiles (xPos, yPos, tileIndex, moving, moveVectorX, movevectorY, movespeed)
    this->CreateTileSet(283<<8, 214<<8, 0, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(370<<8, -5<<8, 3, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(593<<8, 300<<8, 9, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(16<<8, 151<<8, 0, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(60<<8, 240<<8, 1, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(25<<8, 18<<8, 5, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(177<<8, 633<<8, 15, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(161<<8, 90<<8, 1, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(807<<8, 16<<8, 5, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(639<<8, 25<<8, 9, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(173<<8, 385<<8, 0, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(294<<8, 507<<8, 1, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(266<<8, 383<<8, 1, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(594<<8, 525<<8, 9, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(125<<8, 828<<8, 1, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(665<<8, 257<<8, 1, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(585<<8, 749<<8, 11, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(659<<8, 516<<8, 26, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(534<<8, 365<<8, 1, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(898<<8, 254<<8, 0, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(719<<8, 55<<8, 0, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(458<<8, 697<<8, 9, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(914<<8, 164<<8, 0, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(8<<8, 335<<8, 5, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(257<<8, 592<<8, 0, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(198<<8, 838<<8, 9, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(488<<8, 894<<8, 0, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(185<<8, 766<<8, 1, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(483<<8, 782<<8, 1, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(936<<8, 19<<8, 1, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(683<<8, 644<<8, 7, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(15<<8, 870<<8, 5, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(195<<8, 171<<8, 0, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(234<<8, 524<<8, 9, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(333<<8, 320<<8, 6, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(674<<8, 853<<8, 26, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(757<<8, 287<<8, 5, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(296<<8, 791<<8, 12, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(404<<8, 934<<8, 0, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(685<<8, 581<<8, 0, false, 0<<8, 0<<8, 1);
    this->CreateTileSet(515<<8, 491<<8, 0, false, 0<<8, 0<<8, 1);
    
    // Add pickups
    this->AddCollectable(687<<8, 41<<8, 14<<8, 20<<8, (void*)fishjump_Sprite, OBJ_SIZE_32X32);
    this->AddCollectable(94<<8, 72<<8, 14<<8, 20<<8, (void*)fishjump_Sprite, OBJ_SIZE_32X32);
    this->AddCollectable(645<<8, 787<<8, 14<<8, 20<<8, (void*)fishjump_Sprite, OBJ_SIZE_32X32);
    this->AddCollectable(67<<8, 390<<8, 14<<8, 20<<8, (void*)fishjump_Sprite, OBJ_SIZE_32X32);
    this->AddCollectable(273<<8, 722<<8, 14<<8, 20<<8, (void*)fishjump_Sprite, OBJ_SIZE_32X32);
    this->AddCollectable(504<<8, 715<<8, 14<<8, 20<<8, (void*)fishjump_Sprite, OBJ_SIZE_32X32);
    this->AddCollectable(517<<8, 926<<8, 14<<8, 20<<8, (void*)fishjump_Sprite, OBJ_SIZE_32X32);
    this->AddCollectable(701<<8, 295<<8, 14<<8, 20<<8, (void*)fishjump_Sprite, OBJ_SIZE_32X32);
    this->AddCollectable(968<<8, 54<<8, 14<<8, 20<<8, (void*)fishjump_Sprite, OBJ_SIZE_32X32);
    this->AddCollectable(486<<8, 746<<8, 14<<8, 20<<8, (void*)fishjump_Sprite, OBJ_SIZE_32X32);
    this->AddCollectable(818<<8, 804<<8, 14<<8, 20<<8, (void*)fishjump_Sprite, OBJ_SIZE_32X32);
    this->AddCollectable(66<<8, 916<<8, 14<<8, 20<<8, (void*)fishjump_Sprite, OBJ_SIZE_32X32);
    this->AddCollectable(712<<8, 608<<8, 14<<8, 20<<8, (void*)fishjump_Sprite, OBJ_SIZE_32X32);
    this->AddCollectable(468<<8, 712<<8, 14<<8, 20<<8, (void*)fishjump_Sprite, OBJ_SIZE_32X32);
    this->AddCollectable(82<<8, 952<<8, 14<<8, 20<<8, (void*)fishjump_Sprite, OBJ_SIZE_32X32);
    
    // Add signs
    this->AddSign(402<<8, 180<<8, 35<<8, 52<<8, (void*)sign_3_Sprite, OBJ_SIZE_64X64, "Danger! Sharks!");
    this->AddSign(599<<8, 191<<8, 35<<8, 52<<8, (void*)sign_3_Sprite, OBJ_SIZE_64X64, "I hope you're hungry!");
    this->AddSign(385<<8, 471<<8, 35<<8, 52<<8, (void*)sign_3_Sprite, OBJ_SIZE_64X64, "Thin ice !");
    this->AddSign(490<<8, 466<<8, 35<<8, 52<<8, (void*)sign_3_Sprite, OBJ_SIZE_64X64, "Shortcut!");
    
    // Add checkpoints
    this->AddCheckpoint(593<<8, 57<<8, 30<<8, 50<<8, (void*)snowman_Sprite, OBJ_SIZE_64X64);
    this->AddCheckpoint(60<<8, 53<<8, 30<<8, 50<<8, (void*)snowman_Sprite, OBJ_SIZE_64X64);
    this->AddCheckpoint(827<<8, 342<<8, 30<<8, 50<<8, (void*)snowman_Sprite, OBJ_SIZE_64X64);
    this->AddCheckpoint(196<<8, 697<<8, 30<<8, 50<<8, (void*)snowman_Sprite, OBJ_SIZE_64X64);
    this->AddCheckpoint(433<<8, 402<<8, 30<<8, 50<<8, (void*)snowman_Sprite, OBJ_SIZE_64X64);
    this->AddCheckpoint(388<<8, 813<<8, 30<<8, 50<<8, (void*)snowman_Sprite, OBJ_SIZE_64X64);
    
    // Add penguin
    this->AddPenguin(507<<8, 135<<8);
    
    // Add polar bear(s)
    
    // Add ice blocks
    
    // Add start gate
    this->AddStartGate(503<<8, 107<<8);
    
    // Add finish gate
    this->AddFinishGate(813<<8, 763<<8);
    
    // Create shark nodes - make sure to give the nodes neighbours otherwise the shark will get stuck
    this->sharkNodeCount = 36;
    
    // Create an array of nodes
    this->sharkNodes = new MA_Node[this->sharkNodeCount];
    
    this->sharkNodes[0].X = 154 << 8;
    this->sharkNodes[0].Y = 366 << 8;
    this->sharkNodes[0].AddNeighbour(1);
    this->sharkNodes[0].AddNeighbour(25);
    
    this->sharkNodes[1].X = 132 << 8;
    this->sharkNodes[1].Y = 321 << 8;
    this->sharkNodes[1].AddNeighbour(0);
    this->sharkNodes[1].AddNeighbour(2);
    
    this->sharkNodes[2].X = 152 << 8;
    this->sharkNodes[2].Y = 275 << 8;
    this->sharkNodes[2].AddNeighbour(1);
    this->sharkNodes[2].AddNeighbour(3);
    
    this->sharkNodes[3].X = 200 << 8;
    this->sharkNodes[3].Y = 255 << 8;
    this->sharkNodes[3].AddNeighbour(2);
    this->AddShark(3);
    
    this->sharkNodes[4].X = 631 << 8;
    this->sharkNodes[4].Y = 238 << 8;
    this->sharkNodes[4].AddNeighbour(5);
    this->AddShark(4);
    
    this->sharkNodes[5].X = 519 << 8;
    this->sharkNodes[5].Y = 274 << 8;
    this->sharkNodes[5].AddNeighbour(4);
    this->sharkNodes[5].AddNeighbour(6);
    
    this->sharkNodes[6].X = 403 << 8;
    this->sharkNodes[6].Y = 255 << 8;
    this->sharkNodes[6].AddNeighbour(5);
    this->sharkNodes[6].AddNeighbour(7);
    
    this->sharkNodes[7].X = 344 << 8;
    this->sharkNodes[7].Y = 192 << 8;
    this->sharkNodes[7].AddNeighbour(6);
    this->sharkNodes[7].AddNeighbour(24);
    
    this->sharkNodes[8].X = 392 << 8;
    this->sharkNodes[8].Y = 720 << 8;
    this->sharkNodes[8].AddNeighbour(15);
    this->sharkNodes[8].AddNeighbour(9);
    this->AddShark(8);
    
    this->sharkNodes[9].X = 396 << 8;
    this->sharkNodes[9].Y = 751 << 8;
    this->sharkNodes[9].AddNeighbour(10);
    this->sharkNodes[9].AddNeighbour(8);
    
    this->sharkNodes[10].X = 418 << 8;
    this->sharkNodes[10].Y = 775 << 8;
    this->sharkNodes[10].AddNeighbour(9);
    this->sharkNodes[10].AddNeighbour(28);
    
    this->sharkNodes[11].X = 566 << 8;
    this->sharkNodes[11].Y = 703 << 8;
    this->sharkNodes[11].AddNeighbour(12);
    this->sharkNodes[11].AddNeighbour(30);
    this->AddShark(11);
    
    this->sharkNodes[12].X = 533 << 8;
    this->sharkNodes[12].Y = 672 << 8;
    this->sharkNodes[12].AddNeighbour(13);
    this->sharkNodes[12].AddNeighbour(11);
    
    this->sharkNodes[13].X = 506 << 8;
    this->sharkNodes[13].Y = 650 << 8;
    this->sharkNodes[13].AddNeighbour(14);
    this->sharkNodes[13].AddNeighbour(12);
    
    this->sharkNodes[14].X = 459 << 8;
    this->sharkNodes[14].Y = 660 << 8;
    this->sharkNodes[14].AddNeighbour(15);
    this->sharkNodes[14].AddNeighbour(13);
    
    this->sharkNodes[15].X = 418 << 8;
    this->sharkNodes[15].Y = 672 << 8;
    this->sharkNodes[15].AddNeighbour(8);
    this->sharkNodes[15].AddNeighbour(14);
    
    this->sharkNodes[16].X = 605 << 8;
    this->sharkNodes[16].Y = 731 << 8;
    this->sharkNodes[16].AddNeighbour(17);
    this->sharkNodes[16].AddNeighbour(20);
    
    this->sharkNodes[17].X = 661 << 8;
    this->sharkNodes[17].Y = 687 << 8;
    this->sharkNodes[17].AddNeighbour(16);
    this->sharkNodes[17].AddNeighbour(18);
    this->AddShark(17);
    
    this->sharkNodes[18].X = 782 << 8;
    this->sharkNodes[18].Y = 627 << 8;
    this->sharkNodes[18].AddNeighbour(17);
    this->sharkNodes[18].AddNeighbour(19);
    
    this->sharkNodes[19].X = 927 << 8;
    this->sharkNodes[19].Y = 653 << 8;
    this->sharkNodes[19].AddNeighbour(18);
    this->sharkNodes[19].AddNeighbour(23);
    
    this->sharkNodes[20].X = 568 << 8;
    this->sharkNodes[20].Y = 886 << 8;
    this->sharkNodes[20].AddNeighbour(21);
    this->sharkNodes[20].AddNeighbour(16);
    
    this->sharkNodes[21].X = 728 << 8;
    this->sharkNodes[21].Y = 946 << 8;
    this->sharkNodes[21].AddNeighbour(22);
    this->sharkNodes[21].AddNeighbour(20);
    
    this->sharkNodes[22].X = 915 << 8;
    this->sharkNodes[22].Y = 911 << 8;
    this->sharkNodes[22].AddNeighbour(23);
    this->sharkNodes[22].AddNeighbour(21);
    this->AddShark(22);
    
    this->sharkNodes[23].X = 954 << 8;
    this->sharkNodes[23].Y = 864 << 8;
    this->sharkNodes[23].AddNeighbour(19);
    this->sharkNodes[23].AddNeighbour(22);
    
    this->sharkNodes[24].X = 322 << 8;
    this->sharkNodes[24].Y = 132 << 8;
    this->sharkNodes[24].AddNeighbour(7);
    
    this->sharkNodes[25].X = 154 << 8;
    this->sharkNodes[25].Y = 413 << 8;
    this->sharkNodes[25].AddNeighbour(0);
    this->sharkNodes[25].AddNeighbour(26);
    
    this->sharkNodes[26].X = 172 << 8;
    this->sharkNodes[26].Y = 463 << 8;
    this->sharkNodes[26].AddNeighbour(25);
    this->sharkNodes[26].AddNeighbour(27);
    
    this->sharkNodes[27].X = 236 << 8;
    this->sharkNodes[27].Y = 500 << 8;
    this->sharkNodes[27].AddNeighbour(26);
    
    this->sharkNodes[28].X = 458 << 8;
    this->sharkNodes[28].Y = 798 << 8;
    this->sharkNodes[28].AddNeighbour(29);
    this->sharkNodes[28].AddNeighbour(10);
    
    this->sharkNodes[29].X = 514 << 8;
    this->sharkNodes[29].Y = 775 << 8;
    this->sharkNodes[29].AddNeighbour(30);
    this->sharkNodes[29].AddNeighbour(28);
    
    this->sharkNodes[30].X = 557 << 8;
    this->sharkNodes[30].Y = 758 << 8;
    this->sharkNodes[30].AddNeighbour(11);
    this->sharkNodes[30].AddNeighbour(29);
    
    this->sharkNodes[31].X = 886 << 8;
    this->sharkNodes[31].Y = 167 << 8;
    this->sharkNodes[31].AddNeighbour(32);
    this->sharkNodes[31].AddNeighbour(33);
    
    this->sharkNodes[32].X = 967 << 8;
    this->sharkNodes[32].Y = 137 << 8;
    this->sharkNodes[32].AddNeighbour(35);
    this->sharkNodes[32].AddNeighbour(31);
    
    this->sharkNodes[33].X = 894 << 8;
    this->sharkNodes[33].Y = 237 << 8;
    this->sharkNodes[33].AddNeighbour(31);
    this->sharkNodes[33].AddNeighbour(34);
    this->AddShark(33);
    
    this->sharkNodes[34].X = 981 << 8;
    this->sharkNodes[34].Y = 260 << 8;
    this->sharkNodes[34].AddNeighbour(35);
    this->sharkNodes[34].AddNeighbour(33);
    
    this->sharkNodes[35].X = 1004 << 8;
    this->sharkNodes[35].Y = 202 << 8;
    this->sharkNodes[35].AddNeighbour(34);
    this->sharkNodes[35].AddNeighbour(32);
    
}
