#include "..\..\MA_Shared.h"
#include <string>

#pragma once


using std::string;

class MA_EntityDescription
{
public:
		// entity type
		EntityType eType;

		// entity Data
		bool useGfx;
		s32 x;
		s32 y;
		s32 offsetX;
		s32 offsetY;
		void* spriteData;
		u8 shape;
		u8 size;
		u8 paletteID;
		bool autoSortDepth;

		//sign Data
		string signText;
		u8 signFrame;
		// tile Data
		bool isMoving;
		s32 moveVectorX;
		s32 moveVectorY;
		s32 moveSpeed;
		u8 tileIndex;
		u8 tileGroupIndex;

		// shark data
		u16 sharkStartNode;

		MA_EntityDescription(EntityType eType,
			s32 x, s32 y, s32 offsetX, s32 offsetY, void* spriteData, u8 shape, u8 size, u8 paletteID);
};